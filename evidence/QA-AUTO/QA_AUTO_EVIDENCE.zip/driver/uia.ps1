param([int]$ProcId, [string]$Button, [string]$Title = '', [int]$TimeoutSec = 10, [switch]$Probe)
# Press a button by its text in a visible dialog (#32770) of the QA process only.
# Windows' prompts and TaskDialogs keep real Win32 "Button" child windows (text "是(&Y)", "替换"...), while UI
# Automation shows them as CCPushButton panes without an Invoke pattern; so the Win32 button is clicked with a
# posted BM_CLICK (never a blocking send into a modal loop). UIA Buttons are the fallback.
# -Button: regex on the text with '&' removed. -Title: optional substring of the dialog title. -Probe: list.
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
Add-Type @"
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class D2 {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  public static string Text(IntPtr h) { var t = new StringBuilder(256); GetWindowText(h, t, 256); return t.ToString(); }
  public static string Cls(IntPtr h) { var c = new StringBuilder(64); GetClassName(h, c, 64); return c.ToString(); }
  public static List<IntPtr> Dialogs(uint want) {
    var list = new List<IntPtr>();
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid);
      if (pid == want && IsWindowVisible(h) && Cls(h) == "#32770") list.Add(h); return true; }, IntPtr.Zero);
    return list;
  }
  public static List<IntPtr> Buttons(IntPtr dlg) {
    var list = new List<IntPtr>();
    EnumChildWindows(dlg, (h, l) => { if (Cls(h) == "Button" && IsWindowVisible(h) && Text(h).Length > 0) list.Add(h); return true; }, IntPtr.Zero);
    return list;
  }
}
"@
$btnCond = New-Object Windows.Automation.PropertyCondition([Windows.Automation.AutomationElement]::ControlTypeProperty, [Windows.Automation.ControlType]::Button)
$deadline = (Get-Date).AddSeconds($TimeoutSec)
do {
  $seen = @()
  foreach ($h in [D2]::Dialogs([uint32]$ProcId)) {
    $winName = [D2]::Text($h)
    if ($Title -and -not $winName.Contains($Title)) { continue }
    foreach ($b in [D2]::Buttons($h)) {
      $label = [D2]::Text($b).Replace('&', '')
      $seen += "[$winName] $label"
      if (-not $Probe -and $label -match $Button) {
        [void][D2]::PostMessageW($b, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero)   # BM_CLICK, posted
        Start-Sleep -Milliseconds 1000
        "PRESSED $label"
        exit 0
      }
    }
    try {
      $w = [Windows.Automation.AutomationElement]::FromHandle($h)
      foreach ($e in $w.FindAll([Windows.Automation.TreeScope]::Descendants, $btnCond)) {
        $name = $e.Current.Name
        $seen += "[$winName] uia:$name"
        if (-not $Probe -and $name -match $Button) {
          $e.GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern).Invoke()
          Start-Sleep -Milliseconds 1000
          "PRESSED uia:$name"
          exit 0
        }
      }
    } catch { }
  }
  if ($Probe) { if ($seen) { $seen -join ' | ' } else { 'NO_DIALOG' }; exit 0 }
  Start-Sleep -Milliseconds 300
} while ((Get-Date) -lt $deadline)
"NO_BUTTON $Button (seen: $($seen -join ' | '))"
exit 3
