﻿param([string]$Exe, [string]$Out, [string]$Fixtures)
# Automated stand-in for human QA Q1 (export overwrite, keep, replace, failure, retry) and Q2 (stale replace),
# on the desktop Compare page, with real native dialogs: the Windows Save dialog, its overwrite prompt and the
# app's own replace prompt are all answered through Win32 messages and UI Automation, against the QA process
# only. Sentinel files sit in a scratch folder; the non-writable folder is made non-writable for this user
# with an ACL on that scratch folder only. The QA store is KEPT; the Owner's store is only hashed.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$work = Join-Path $Out 'files'
$locked = Join-Path $Out 'locked'
New-Item -ItemType Directory -Force $work, $locked | Out-Null
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.q1-aside-" + (Get-Date -Format "HHmmss")
if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $aside }
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Click($name) { node cdp.mjs click $name | Out-Null }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
function Hash($f) { if (Test-Path $f) { (Get-FileHash $f).Hash } else { 'ABSENT' } }
function Status { J "[...document.querySelectorAll('[role=status],[role=alert]')].map(n => n.textContent).filter(Boolean).join(' | ')" }
function Sentinel($f) { [IO.File]::WriteAllText($f, "SENTINEL $(Split-Path -Leaf $f) - must survive cancel, deny, keep and failure") ; Hash $f }
function Export($label) { Click '导出'; Start-Sleep 1; Click $label }
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null
  foreach ($side in 'base', 'target') {
    Click '选择固件镜像文件'; & .\dialog.ps1 -ProcId $p.Id -Title '选择要分析的固件文件' -FilePath "$Fixtures\$side\firmware.elf" | Out-Null; Start-Sleep 1
    Click '分析'; Start-Sleep 3
  }
  Click '对比 页面'; Start-Sleep 2
  Click '对比'; Start-Sleep 4

  $target = Join-Path $work 'report.html'

  # (a) Save over a sentinel, deny at the Windows overwrite prompt, then cancel the Save dialog.
  $h0 = Sentinel $target
  Export '导出 HTML'
  $d = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath $target
  $os = & .\uia.ps1 -ProcId $p.Id -Title '确认另存为' -Button '^否' -TimeoutSec 5
  $c = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath '' -Cancel
  Start-Sleep 1
  $st = Status
  Rec 'Q1a' (V ((Hash $target) -eq $h0 -and $os -match 'PRESSED' -and $st -notmatch '已写入')) "deny at the Windows overwrite prompt ($os), then cancel ($c): sentinel unchanged; status: $st"

  # (b) Accept the Windows prompt, keep the file at the app's own prompt.
  Export '导出 HTML'
  $d = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath $target
  $os = & .\uia.ps1 -ProcId $p.Id -Title '确认另存为' -Button '^是' -TimeoutSec 5
  $app = & .\uia.ps1 -ProcId $p.Id -Title '替换已有文件' -Button '保留原文件' -TimeoutSec 8
  Start-Sleep 1
  $st = Status
  Rec 'Q1b' (V ((Hash $target) -eq $h0 -and $app -match 'PRESSED' -and $st -match '保留了已经存在的文件')) "Windows prompt ($os), app prompt Keep ($app): sentinel unchanged; status: $st"

  # (c) Accept both: exactly the chosen file is replaced.
  $others = Get-ChildItem $work | Where-Object Name -ne 'report.html' | Measure-Object | Select-Object -ExpandProperty Count
  Export '导出 HTML'
  $d = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath $target
  $os = & .\uia.ps1 -ProcId $p.Id -Title '确认另存为' -Button '^是' -TimeoutSec 5
  $app = & .\uia.ps1 -ProcId $p.Id -Title '替换已有文件' -Button '^替换$' -TimeoutSec 8
  Start-Sleep 2
  $st = Status
  $body = if (Test-Path $target) { Get-Content -Raw $target } else { '' }
  $after = Get-ChildItem $work | Where-Object Name -ne 'report.html' | Measure-Object | Select-Object -ExpandProperty Count
  Rec 'Q1c' (V ((Hash $target) -ne $h0 -and $body -match '<html' -and $after -eq $others -and $st -match '已写入')) "Replace ($app): report.html now an HTML report, no other file created or left (temp files: $after); status: $st"

  # (d1) A folder this user may not write: Windows' own Save dialog refuses it before the app sees a path.
  $acl = & icacls $locked /deny "$($env:USERNAME):(W,WD,AD)" 2>&1 | Out-String
  $denied = Join-Path $locked 'report.html'
  Export '导出 HTML'
  $d = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath $denied
  Start-Sleep 2
  $osNo = & .\uia.ps1 -ProcId $p.Id -Title '保存' -Button '^否' -TimeoutSec 5
  $c = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath '' -Cancel
  Start-Sleep 1
  $st = Status
  $left = (Get-ChildItem -Force $locked -ErrorAction SilentlyContinue | Measure-Object).Count
  Rec 'Q1d1' (V ($osNo -match 'PRESSED' -and $left -eq 0 -and $st -match '已取消导出')) "folder without write access: Windows refused it in the Save dialog ($osNo), then cancel ($c); files there: $left; status: $st"

  # (d2) A read-only target: Windows' Save dialog refuses it too (a second prompt with only OK).
  $ro = Join-Path $work 'readonly.html'
  $hr = Sentinel $ro
  Set-ItemProperty $ro -Name IsReadOnly -Value $true
  Export '导出 HTML'
  $d = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath $ro
  $os = & .\uia.ps1 -ProcId $p.Id -Title '确认另存为' -Button '^是' -TimeoutSec 5
  $ok = & .\uia.ps1 -ProcId $p.Id -Title '保存' -Button '^确定$' -TimeoutSec 5
  $c = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath '' -Cancel
  Start-Sleep 1
  $st = Status
  Rec 'Q1d2' (V ((Hash $ro) -eq $hr -and $ok -match 'PRESSED' -and $st -match '已取消导出')) "read-only target ($os): Windows refused it ($ok), cancel ($c); file unchanged; status: $st"
  Set-ItemProperty $ro -Name IsReadOnly -Value $false

  # (d3) A write that fails inside the app: another program holds the target open with no sharing (an editor
  # with the report open). The Save dialog lets it through; the app's replace must fail, say so with a
  # diagnostics id, and leave the file and no temporary behind.
  $busy = Join-Path $work 'busy.html'
  $hb = Sentinel $busy
  $lock = [IO.File]::Open($busy, 'Open', 'Read', 'None')
  try {
    Export '导出 HTML'
    $d = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath $busy
    $os = & .\uia.ps1 -ProcId $p.Id -Title '确认另存为' -Button '^是' -TimeoutSec 5
    $app = & .\uia.ps1 -ProcId $p.Id -Title '替换已有文件' -Button '^替换$' -TimeoutSec 8
    Start-Sleep 2
    $err = J "[...document.querySelectorAll('[role=alert]')].map(n => n.textContent).join(' | ')"
  } finally { $lock.Dispose() }
  $temps = (Get-ChildItem -Force $work -Filter '.busy.html.tmp-*' | Measure-Object).Count
  Rec 'Q1d3' (V ((Hash $busy) -eq $hb -and $app -match 'PRESSED' -and $err -match '导出失败' -and $temps -eq 0)) "target held open by another program ($os, $app): error panel '$err'; file unchanged; temp files left: $temps"

  # (d4) Retry the same export once the other program lets go: it now succeeds.
  Export '导出 HTML'
  $d = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath $busy
  $os = & .\uia.ps1 -ProcId $p.Id -Title '确认另存为' -Button '^是' -TimeoutSec 5
  $app = & .\uia.ps1 -ProcId $p.Id -Title '替换已有文件' -Button '^替换$' -TimeoutSec 8
  Start-Sleep 2
  $st = Status
  $body = Get-Content -Raw $busy
  Rec 'Q1d4' (V ($body -match '<html' -and $st -match '已写入')) "retry after the file is released ($app): replaced; status: $st"

  # (e) Retry to a writable new name.
  $retry = Join-Path $work 'retry.html'
  Export '导出 HTML'
  $d = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath $retry
  Start-Sleep 2
  $st = Status
  Rec 'Q1e' (V ((Test-Path $retry) -and $st -match '已写入')) "retry to a writable folder: written; status: $st"

  # Q2: the comparison changes while the app's replace prompt is open; Replace is then refused as stale.
  $stale = Join-Path $work 'stale.html'
  $hs = Sentinel $stale
  Export '导出 HTML'
  $d = & .\dialog.ps1 -ProcId $p.Id -Title '保存' -FilePath $stale
  $os = & .\uia.ps1 -ProcId $p.Id -Title '确认另存为' -Button '^是' -TimeoutSec 5
  Start-Sleep 1
  $prompt = & .\uia.ps1 -ProcId $p.Id -Probe
  node cdp.mjs eval "(() => { const b = [...document.querySelectorAll('button')].find(x => x.textContent.trim() === '交换'); b && b.click(); return !!b })()" | Out-Null
  Start-Sleep 1
  Click '对比'
  Start-Sleep 4
  $newPair = J "[...document.querySelectorAll('[role=region]')].find(n => n.getAttribute('aria-label') === '本页主体')?.textContent"
  $retained = J "document.body.textContent.includes('显示的是上一次对比')"

  $app = & .\uia.ps1 -ProcId $p.Id -Title '替换已有文件' -Button '^替换$' -TimeoutSec 8
  Start-Sleep 2
  $st = Status
  $same = (Hash $stale) -eq $hs
  Rec 'Q2' (V ($same -and $app -match 'PRESSED' -and $st -match '没有写入任何文件' -and $retained -eq 'false')) "a new comparison (swapped pair; retained banner: $retained) completed while the replace prompt was open, then Replace ($app): sentinel unchanged: $same; status: $st"

  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  & icacls $locked /remove:d "$($env:USERNAME)" 2>&1 | Out-Null
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.q1-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  if (Test-Path "$a\$aside") { Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa" }
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec 'Q99' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
