﻿param([string]$Exe, [string]$Out, [string]$Source)
# A real OLE drag from an Explorer window onto the QA build, with the real mouse.
# The dragged files are COPIES in a scratch folder; the repository's fixtures are never touched.
# The QA store is KEPT and listed; the Owner's store is only hashed.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$drop = Join-Path $Out 'drop'
New-Item -ItemType Directory -Force $drop | Out-Null
Copy-Item "$Source\firmware.elf" "$drop\firmware.elf" -Force
Copy-Item "$Source\firmware.map" "$drop\firmware.map" -Force
$mapHash = (Get-FileHash "$drop\firmware.map").Hash
$elfHash = (Get-FileHash "$drop\firmware.elf").Hash
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class In {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr v);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int hh, uint f);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, int x, int y, uint d, UIntPtr e);
  [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
}
"@
[void][In]::SetProcessDpiAwarenessContext([IntPtr](-4))
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.q8-aside-" + (Get-Date -Format "HHmmss")
if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $aside }
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
$explorer = $null
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  $p.Refresh(); $app = $p.MainWindowHandle
  [void][In]::SetWindowPos($app, [IntPtr]::Zero, 700, 60, 1200, 900, 0x0040)

  # An Explorer window on the scratch folder, placed beside the app.
  $before_ex = @((New-Object -ComObject Shell.Application).Windows() | ForEach-Object { $_.HWND })
  Start-Process explorer.exe $drop
  $deadline = (Get-Date).AddSeconds(15)
  while (-not $explorer -and (Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 500
    $explorer = (New-Object -ComObject Shell.Application).Windows() | Where-Object { $before_ex -notcontains $_.HWND -and $_.Document.Folder.Self.Path -eq $drop } | Select-Object -First 1
  }
  if (-not $explorer) { throw 'no Explorer window on the drop folder' }
  $exh = [IntPtr]$explorer.HWND
  [void][In]::SetWindowPos($exh, [IntPtr]::Zero, 20, 60, 660, 600, 0x0040)
  [void][In]::SetForegroundWindow($exh); Start-Sleep 2

  # Find the file's list item with UI Automation and grab its centre.
  $root = [Windows.Automation.AutomationElement]::FromHandle($exh)
  $cond = New-Object Windows.Automation.PropertyCondition([Windows.Automation.AutomationElement]::NameProperty, 'firmware.elf')
  $item = $null; $deadline = (Get-Date).AddSeconds(10)
  while (-not $item -and (Get-Date) -lt $deadline) { $item = $root.FindFirst([Windows.Automation.TreeScope]::Descendants, $cond); if (-not $item) { Start-Sleep -Milliseconds 500 } }
  if (-not $item) { throw 'firmware.elf not found in the Explorer view' }
  # Select both files the way a person does (click one, Ctrl-click the other), through UI Automation.
  $mapCond = New-Object Windows.Automation.PropertyCondition([Windows.Automation.AutomationElement]::NameProperty, 'firmware.map')
  $mapItem = $root.FindFirst([Windows.Automation.TreeScope]::Descendants, $mapCond)
  if (-not $mapItem) { throw 'firmware.map not found in the Explorer view' }
  $item.GetCurrentPattern([Windows.Automation.SelectionItemPattern]::Pattern).Select()
  $mapItem.GetCurrentPattern([Windows.Automation.SelectionItemPattern]::Pattern).AddToSelection()
  Start-Sleep -Milliseconds 500
  $b = $item.Current.BoundingRectangle
  $sx = [int]($b.X + [math]::Min(40, $b.Width / 2)); $sy = [int]($b.Y + $b.Height / 2)
  $r = New-Object In+RECT; [void][In]::GetWindowRect($app, [ref]$r)
  $tx = [int](($r.L + $r.R) / 2); $ty = [int](($r.T + $r.B) / 2)

  [void][In]::SetCursorPos($sx, $sy); Start-Sleep -Milliseconds 300
  [In]::mouse_event(0x2, 0, 0, 0, [UIntPtr]::Zero)
  for ($i = 1; $i -le 30; $i++) { [void][In]::SetCursorPos([int]($sx + ($tx - $sx) * $i / 30), [int]($sy + ($ty - $sy) * $i / 30)); Start-Sleep -Milliseconds 50 }
  Start-Sleep -Milliseconds 600
  [In]::mouse_event(0x4, 0, 0, 0, [UIntPtr]::Zero)
  Start-Sleep 6

  $state = J "({ built: document.body.textContent.includes('firmware.elf · 3c9daa4f7c09'), map: document.body.textContent.includes('MAP：firmware.map'), lead: document.body.textContent.includes('Flash 已用'), paths: /[A-Za-z]:[\\\/]|\/Users\//.test(document.body.innerText), alerts: document.querySelectorAll('[role=alert]').length })"
  $still = ((Get-FileHash "$drop\firmware.elf").Hash -eq $elfHash) -and ((Get-FileHash "$drop\firmware.map").Hash -eq $mapHash)
  Rec 'Q8' (V ($state -match '"built": true' -and $state -match '"map": true' -and $state -match '"lead": true' -and $state -match '"paths": false' -and $state -match '"alerts": 0' -and $still)) "real mouse drag of firmware.elf + firmware.map together from Explorer (from $sx,$sy to $tx,$ty): $state; both files unchanged: $still"
  node cdp.mjs shot "$Out\01-after-explorer-drop.png" | Out-Null

  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  if ($explorer) { try { $explorer.Quit() } catch {} }
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.q8-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  if (Test-Path "$a\$aside") { Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa" }
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec 'Q8-owner' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
