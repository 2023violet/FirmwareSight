param([string]$Exe, [string]$Out, [string]$Fixtures)
# R6 native smoke: Markdown export from the three pages through the real Save dialog, QA build only.
# The QA store and the written reports are KEPT and listed, never deleted.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$docs = Join-Path $Out 'reports'
New-Item -ItemType Directory -Force $docs | Out-Null
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.r6-aside-" + (Get-Date -Format "HHmmss")
if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $aside }
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Click($name) { node cdp.mjs click $name | Out-Null }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
function JClick($expr) { J "(() => { const el = $expr; if (!el) return 'MISSING'; el.click(); return 'ok' })()" }
function Region($name) { "[...document.querySelectorAll('[aria-label]')].find(n => n.getAttribute('aria-label') === '$name')" }
function ExportMarkdown($file) {
  Click '导出'
  Start-Sleep 1
  Click '导出 Markdown'
  $d = & .\dialog.ps1 -ProcId $p.Id -FilePath $file
  Start-Sleep 2
  return $d
}
function Doc($file) { if (Test-Path $file) { Get-Content -Raw -Encoding utf8 $file } else { '' } }
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null

  foreach ($side in 'base', 'target') {
    Click '选择固件镜像文件'
    & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\firmware.elf" | Out-Null
    Start-Sleep 1
    Click '添加 MAP'
    & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\firmware.map" | Out-Null
    Start-Sleep 1
    Click '分析'
    Start-Sleep 3
  }

  $analysis = Join-Path $docs 'analysis.md'
  $d1 = ExportMarkdown $analysis
  $doc = Doc $analysis
  $status = J "[...document.querySelectorAll('[role=status]')].map(n => n.textContent).join(' | ')"
  Rec 'M01' (V ($doc.StartsWith('# FirmwareSight · Analysis report') -and $doc -match '3c9daa4f7c09' -and $doc -notmatch '<[a-z/]' -and $doc -notmatch 'fixtures')) "Analyze > Export Markdown wrote $(Split-Path -Leaf $analysis) ($($doc.Length) chars); dialog $d1; status: $status"
  node cdp.mjs shot "$Out\01-analyze-export-menu.png" | Out-Null

  Click '对比 页面'
  Start-Sleep 2
  Click '对比'
  Start-Sleep 3
  $compare = Join-Path $docs 'comparison.md'
  $d2 = ExportMarkdown $compare
  $doc2 = Doc $compare
  Rec 'M02' (V ($doc2.StartsWith('# FirmwareSight · Comparison report') -and $doc2 -match '▲64 bytes' -and $doc2 -match '— \(one side not present\)' -and $doc2 -notmatch '<[a-z/]')) "Compare > Export Markdown wrote $(Split-Path -Leaf $compare) ($($doc2.Length) chars); dialog $d2"

  Click '发布 页面'
  Start-Sleep 2
  Click '运行 Gate'
  Start-Sleep 3
  $gate = Join-Path $docs 'gate.md'
  $d3 = ExportMarkdown $gate
  $doc3 = Doc $gate
  $na = if ($doc3.Contains('### **N/A**')) { $doc3.Substring($doc3.IndexOf('### **N/A**')) } else { '' }
  Rec 'M03' (V ($doc3.StartsWith('# FirmwareSight · Release Gate report') -and $doc3 -match 'not a certification' -and $na -notmatch '\*\*PASS\*\*' -and $doc3 -notmatch '<[a-z/]')) "Release > Export Markdown wrote $(Split-Path -Leaf $gate) ($($doc3.Length) chars); N/A rows show no severity; dialog $d3"
  node cdp.mjs shot "$Out\02-release-after-markdown.png" | Out-Null

  Click '导出'
  Start-Sleep 1
  Click '导出 Markdown'
  $c = & .\dialog.ps1 -ProcId $p.Id -FilePath '' -Cancel
  Start-Sleep 1
  $status = J "[...document.querySelectorAll('[role=status]')].map(n => n.textContent).join(' | ')"
  $alerts = J "document.querySelectorAll('[role=alert]').length"
  Rec 'M04' (V ($c -eq 'DIALOG_CANCELLED' -and $status -match '已取消导出' -and $alerts -eq '0')) "cancelled Markdown export writes nothing and is not an error: $c (alerts $alerts)"

  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.r6-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  if (Test-Path "$a\$aside") { Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa" }
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec 'M05' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
