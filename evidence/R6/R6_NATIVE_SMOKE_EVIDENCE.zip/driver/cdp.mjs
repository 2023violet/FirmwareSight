// Minimal CDP driver for the QA desktop window (WebView2 remote debugging on 9333).
// Usage: node cdp.mjs eval "<expr>" | shot <file.png> | click "<accessible name>" | errors
import { writeFileSync } from 'node:fs';

const list = await (await fetch('http://127.0.0.1:9333/json/list')).json();
const page = list.find((t) => t.type === 'page' && t.url.startsWith('http://tauri.localhost'));
if (!page) throw new Error('no tauri page target');
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener('open', r, { once: true }));
let id = 0;
const pending = new Map();
ws.addEventListener('message', (e) => {
  const m = JSON.parse(e.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
});
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const evaluate = async (expr) => {
  const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails));
  return r.result?.result?.value;
};
const [cmd, arg] = process.argv.slice(2);
if (cmd === 'eval') {
  console.log(JSON.stringify(await evaluate(arg), null, 1));
} else if (cmd === 'shot') {
  const r = await send('Page.captureScreenshot', { format: 'png' });
  writeFileSync(arg, Buffer.from(r.result.data, 'base64'));
  console.log('saved', arg);
} else if (cmd === 'darkshot') {
  // Emulation lasts only while this connection is open, so set, read and capture in one go.
  await send('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-color-scheme', value: 'dark' }] });
  await new Promise((r) => setTimeout(r, 800));
  console.log(JSON.stringify(await evaluate(`({ theme: document.documentElement.getAttribute('data-fs-theme'), bg: getComputedStyle(document.body).backgroundColor, removed: getComputedStyle(document.documentElement).getPropertyValue('--fs-color-diff-removed') })`)));
  const r = await send('Page.captureScreenshot', { format: 'png' });
  writeFileSync(arg, Buffer.from(r.result.data, 'base64'));
  await send('Emulation.setEmulatedMedia', { features: [] });
  console.log('saved', arg);
} else if (cmd === 'media') {
  // prefers-color-scheme emulation; the app's theme is `system`, so it follows.
  await send('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-color-scheme', value: arg }] });
  await new Promise((r) => setTimeout(r, 400));
  console.log('media', arg);
} else if (cmd === 'click') {
  const box = await evaluate(`(() => { const el = [...document.querySelectorAll('button,[role=tab]')].find(b => (b.getAttribute('aria-label') ?? b.textContent.trim()) === ${JSON.stringify(arg)}); if (!el) return null; el.scrollIntoView({block:'center'}); const r = el.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; })()`);
  if (!box) { console.log('NOT FOUND', arg); process.exit(2); }
  for (const type of ['mousePressed', 'mouseReleased']) {
    await send('Input.dispatchMouseEvent', { type, x: box.x, y: box.y, button: 'left', clickCount: 1 });
  }
  await new Promise((r) => setTimeout(r, 300));
  console.log('clicked', arg);
}
ws.close();
