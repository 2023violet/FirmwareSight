param([int]$ProcId, [int]$W, [int]$H)
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class Win {
  [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr h, int x, int y, int w, int hh, bool r);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
}
"@
$hwnd = (Get-Process -Id $ProcId).MainWindowHandle
[void][Win]::MoveWindow($hwnd, 40, 40, $W, $H, $true)
Start-Sleep -Milliseconds 700
$r = New-Object Win+RECT
[void][Win]::GetWindowRect($hwnd, [ref]$r)
"requested ${W}x${H} -> outer $($r.R - $r.L)x$($r.B - $r.T)"
