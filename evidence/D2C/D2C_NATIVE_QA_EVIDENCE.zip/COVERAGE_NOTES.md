# Coverage notes (D2C C2)

What this automated pass shows, and what it does not.

- **Observed:** the M2 screens rendered by the real QA build on this host, driven through the page and the real native file pickers.
  Values were read from the DOM and cross-checked against the CLI (A11).
- **First results kept:** A09 FAILED on the first run because the driver's selector read only the panel's header block. The
  screenshot (shots/A09_overview_latest.png) shows the full panel was rendered. A09-rerun, with the selector corrected to the
  panel section, passed. Both lines are in results.jsonl and AC_MATRIX.tsv.
- **Not shown:** keyboard-only use and the focus ring; a screen reader; the app's own theme setting (A10 emulated the OS
  colour scheme instead); 1440x900; the English UI; a human's reading of the screens; a non-Owner Windows profile; native
  drag and drop. These belong to the human pass (evidence/D2C/HUMAN_NATIVE_QA_RUNBOOK.md, H01-H12).
- **Not a closure of AC24 / AC26 / AC20:** this pass does not touch export dialogs and does not change their state.
