// A09 re-run with a corrected selector (the first run read only the panel header block), and A11, the
// UI-versus-CLI cross-check. Appends to results.jsonl; the first A09 line stays as recorded.
//   node rerun.mjs <qaDir> <fwsight.exe>
import { appendFileSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';

const [, , QA, CLI] = process.argv;
const RES = join(QA, 'results.jsonl');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const list = await (await fetch('http://127.0.0.1:9333/json/list')).json();
const page = list.find((t) => t.type === 'page' && t.url.startsWith('http://tauri.localhost'));
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let id = 0;
const pending = new Map();
ws.onmessage = (m) => { const msg = JSON.parse(m.data); if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); } };
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const js = async (expression) => (await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })).result?.result?.value;
const rec = (c, title, expected, actual, pass) => {
  const line = { case: c, title, expected, actual: String(actual), verdict: pass ? 'PASS' : 'FAIL', utc: new Date().toISOString().slice(0, 19) + 'Z' };
  appendFileSync(RES, JSON.stringify(line) + '\n');
  console.log(c, line.verdict, '-', line.actual.slice(0, 200));
};
const clickNav = async (label) => {
  const at = await js(`(() => { const b = [...document.querySelectorAll('button')].find((e) => (e.getAttribute('aria-label') || e.textContent || '').trim() === '${label} 页面'); if (!b) return null; const r = b.getBoundingClientRect(); return {x: r.left + r.width/2, y: r.top + r.height/2}; })()`);
  for (const type of ['mousePressed', 'mouseReleased']) await send('Input.dispatchMouseEvent', { type, x: at.x, y: at.y, button: 'left', clickCount: 1 });
  await sleep(1500);
};

await clickNav('总览');
const ov = await js(`(() => { const h = [...document.querySelectorAll('h2,h3')].find((e) => e.textContent.trim() === '最近一次比较'); return h?.closest('section')?.innerText ?? '' })()`);
rec('A09-rerun', 'Overview latest comparison (selector corrected: the panel section, not its header block)',
  'both file names, a signed Flash change, comparability, the largest object growth',
  JSON.stringify(ov.replace(/\s+/g, ' ').slice(0, 260)),
  (ov.match(/firmware\.elf/g) || []).length >= 2 && /Flash 变化\s*\+\d+ bytes/.test(ov) && /增长最多的对象\s*sensors\/imu\.o \+\d+ bytes/.test(ov));

// A11: the target rows the UI showed equal the CLI's --objects table for the same files.
const ui = JSON.parse(readFileSync(join(QA, 'ui_target_rows.json'), 'utf8'));
const txt = execFileSync(CLI, ['analyze', join(QA, 'in', 'target', 'firmware.elf'), '--map', join(QA, 'in', 'target', 'firmware.map'), '--objects'], { encoding: 'utf8' });
const cli = {};
for (const line of txt.split('\n')) {
  const m = line.match(/^\s+(\d+) bytes\s+(\d+) bytes\s+(\d+)\s+(\S+)$/);
  if (m) cli[m[4]] = [`${m[1]} bytes`, `${m[2]} bytes`, m[3]];
}
const mismatches = ui.filter((r) => !cli[r[0]] || cli[r[0]][0] !== r[2] || cli[r[0]][1] !== r[3] || cli[r[0]][2] !== r[5]);
rec('A11', 'UI object rows equal `fwsight analyze --objects` on the same files', 'every UI row has the same Flash, RAM and MAP-row count in the CLI table',
  `ui=${ui.length} cli=${Object.keys(cli).length} mismatches=${JSON.stringify(mismatches)}`, ui.length === 4 && mismatches.length === 0);

ws.close();
process.exit(0);
