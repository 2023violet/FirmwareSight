// Minimal WebView2 CDP driver for M1 native QA. One command per invocation.
//   node cdp.mjs eval "<js expression>"
//   node cdp.mjs click "<accessible name>" [role]      (button|tab|link|radio|option|any)
//   node cdp.mjs key <Key> [shift]                       (Tab, Enter, Escape, ArrowDown, " ")
//   node cdp.mjs shot <file.png>
//   node cdp.mjs text                                    (document.body.innerText)
//   node cdp.mjs focus                                   (describe document.activeElement)
//   node cdp.mjs viewport <width> <height>               (Emulation.setDeviceMetricsOverride; 0 0 clears)
import { writeFileSync } from 'node:fs';

const PORT = process.env.CDP_PORT ?? '9333';
const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
const page = list.find((t) => t.type === 'page' && t.url.startsWith('http://tauri.localhost'));
if (!page) throw new Error('no tauri page target: ' + JSON.stringify(list.map((t) => t.url)));
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let id = 0;
const pending = new Map();
ws.onmessage = (m) => {
  const msg = JSON.parse(m.data);
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
};
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const evaluate = async (expression) => {
  const res = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (res.result?.exceptionDetails) throw new Error(JSON.stringify(res.result.exceptionDetails));
  return res.result?.result?.value;
};

const FIND = (name, role) => `(() => {
  const want = ${JSON.stringify(name)}; const role = ${JSON.stringify(role ?? 'any')};
  const nameOf = (el) => (el.getAttribute('aria-label') || (el.labels && el.labels[0] && el.labels[0].textContent) || el.textContent || '').trim().replace(/\\s+/g,' ');
  const sel = role === 'button' ? 'button,[role=button]' : role === 'tab' ? '[role=tab]' : role === 'link' ? 'a,[role=link]' : role === 'radio' ? 'input[type=radio]' : role === 'option' ? 'option' : 'button,[role=button],[role=tab],a,input,select,summary,label';
  const hits = [...document.querySelectorAll(sel)].filter((el) => nameOf(el) === want && el.getClientRects().length > 0);
  if (hits.length === 0) return null;
  const el = hits[0]; el.scrollIntoView({block:'center'});
  const r = el.getBoundingClientRect();
  return { x: r.left + r.width / 2, y: r.top + r.height / 2, count: hits.length };
})()`;

const [, , cmd, a, b] = process.argv;
let out;
if (cmd === 'eval') out = await evaluate(a);
else if (cmd === 'text') out = await evaluate('document.body.innerText');
else if (cmd === 'focus') out = await evaluate(`(() => { const e = document.activeElement; return e ? { tag: e.tagName, name: (e.getAttribute('aria-label') || e.textContent || '').trim().slice(0,80), role: e.getAttribute('role'), id: e.id } : null })()`);
else if (cmd === 'click') {
  const at = await evaluate(FIND(a, b));
  if (!at) throw new Error('not found: ' + a);
  for (const type of ['mousePressed', 'mouseReleased']) await send('Input.dispatchMouseEvent', { type, x: at.x, y: at.y, button: 'left', clickCount: 1 });
  out = at;
} else if (cmd === 'key') {
  const key = a === 'Space' ? ' ' : a;
  const codes = { Tab: 9, Enter: 13, Escape: 27, ArrowDown: 40, ArrowUp: 38, ' ': 32 };
  const modifiers = b === 'shift' ? 8 : 0;
  for (const type of ['keyDown', 'keyUp']) await send('Input.dispatchKeyEvent', { type, key, code: key === ' ' ? 'Space' : key, windowsVirtualKeyCode: codes[key] ?? 0, modifiers, text: type === 'keyDown' && key === 'Enter' ? '\r' : type === 'keyDown' && key === ' ' ? ' ' : undefined });
  out = { key, modifiers };
} else if (cmd === 'shot') {
  const res = await send('Page.captureScreenshot', { format: 'png' });
  writeFileSync(a, Buffer.from(res.result.data, 'base64'));
  out = a;
} else if (cmd === 'viewport') {
  const w = Number(a), h = Number(b);
  out = w === 0 ? await send('Emulation.clearDeviceMetricsOverride') : await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 0, mobile: false });
} else throw new Error('unknown command ' + cmd);
console.log(JSON.stringify(out));
ws.close();
process.exit(0);
