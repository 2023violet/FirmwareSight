// D2C C2: automated native QA of the M2 screens on the QA-identifier build.
//   node m2pass.mjs <pid> <qaDir>
// Page input goes through the WebView2 DevTools protocol; the native file pickers are driven with Win32
// messages through win.ps1, against windows owned by <pid> only. Every case appends one line to
// <qaDir>/results.jsonl with expected, actual, verdict and UTC. A case is never re-run silently here.
import { appendFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';

const [, , PID, QA] = process.argv;
const RES = join(QA, 'results.jsonl');
writeFileSync(RES, '');
const winIn = (p) => p.replace(/^\/c\//, 'C:\\').replaceAll('/', '\\');
const IN = winIn(join(QA, 'in'));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---- CDP
const list = await (await fetch('http://127.0.0.1:9333/json/list')).json();
const page = list.find((t) => t.type === 'page' && t.url.startsWith('http://tauri.localhost'));
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let id = 0;
const pending = new Map();
ws.onmessage = (m) => { const msg = JSON.parse(m.data); if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); } };
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const js = async (expression) => {
  const res = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (res.result?.exceptionDetails) throw new Error(JSON.stringify(res.result.exceptionDetails).slice(0, 400));
  return res.result?.result?.value;
};
const shot = async (name) => { const r = await send('Page.captureScreenshot', { format: 'png' }); writeFileSync(join(QA, 'shots', name), Buffer.from(r.result.data, 'base64')); };
// Click an element found by a JS predicate, with a real mouse press/release at its centre.
const clickWhere = async (finder) => {
  const at = await js(`(() => { const el = (${finder})(); if (!el) return null; el.scrollIntoView({block:'center'}); const r = el.getBoundingClientRect(); return {x: r.left + r.width/2, y: r.top + r.height/2}; })()`);
  if (!at) return false;
  for (const type of ['mousePressed', 'mouseReleased']) await send('Input.dispatchMouseEvent', { type, x: at.x, y: at.y, button: 'left', clickCount: 1 });
  return true;
};
const byText = (sel, text, scope = 'document') => `() => [...${scope}.querySelectorAll(${JSON.stringify(sel)})].find((e) => (e.getAttribute('aria-label') || e.textContent || '').trim() === ${JSON.stringify(text)} && e.getClientRects().length > 0)`;
const nav = async (label) => { await clickWhere(byText('button', `${label} 页面`)); await sleep(1500); };
const typeInto = async (finder, text) => {
  await clickWhere(finder);
  await js(`(() => { const el = (${finder})(); const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; set.call(el, ${JSON.stringify(text)}); el.dispatchEvent(new Event('input', {bubbles: true})); return 1; })()`);
};

// ---- Win32 dialogs (owned by the QA pid only)
const win = (...args) => execFileSync('pwsh', ['-NoProfile', '-File', join(QA, 'drivers', 'win.ps1'), ...args, '-ProcessId', PID], { encoding: 'utf8' });
const pickFile = async (title, path) => {
  for (let i = 0; i < 20; i++) { try { win('-Action', 'settext', '-Title', title, '-Id', '1148', '-Text', path); break; } catch { await sleep(300); } }
  win('-Action', 'click', '-Title', title, '-Id', '1');
  await sleep(1500);
};

// ---- recording
const rec = (c, title, expected, actual, pass) => {
  const line = { case: c, title, expected, actual: String(actual), verdict: pass ? 'PASS' : 'FAIL', utc: new Date().toISOString().slice(0, 19) + 'Z' };
  appendFileSync(RES, JSON.stringify(line) + '\n');
  console.log(c, line.verdict, '-', line.actual.slice(0, 160));
};

const analyze = async (dir, withMap) => {
  await nav('分析');
  await clickWhere(byText('button', '选择固件镜像文件'));
  await sleep(1500);
  await pickFile('选择要分析的固件文件', `${IN}\\${dir}\\firmware.elf`);
  if (withMap) {
    await clickWhere(byText('button', '添加 MAP'));
    await sleep(1500);
    await pickFile('选择这个固件的链接器 MAP 文件', `${IN}\\${dir}\\firmware.map`);
  } else {
    await clickWhere(byText('button', '移除 MAP'));
    await sleep(500);
  }
  await clickWhere(`() => [...document.querySelectorAll('main button')].find((b) => b.textContent.trim() === '分析' && !b.disabled)`);
  await sleep(3500);
};
const panelText = () => js(`(document.querySelector('[role=tabpanel]')?.innerText) ?? ''`);
const openTab = async (name) => { await clickWhere(byText('[role=tab]', name)); await sleep(1500); };

// A05 first: the base build with no MAP.
await analyze('base', false);
await openTab('对象');
let t = await panelText();
rec('A05', 'Objects tab on a build without a MAP', 'UNKNOWN badge, no-MAP reason, attach-MAP next step, no table',
  `badge=${t.includes('此构建没有对象归因')} reason=${t.includes('GNU ld MAP')} nextStep=${t.includes('附上该构建的 GNU ld .map 文件重新分析')} table=${await js(`!!document.querySelector('[role=tabpanel] table')`)}`,
  t.includes('此构建没有对象归因') && t.includes('附上该构建的 GNU ld .map') && !(await js(`!!document.querySelector('[role=tabpanel] table')`)));
await shot('A05_objects_no_map.png');

// Base with its MAP, then target with its MAP (target is analyzed last).
await analyze('base', true);
await analyze('target', true);
await openTab('对象');
const rows = () => js(`[...document.querySelectorAll('[role=tabpanel] table tbody tr')].map((r) => [...r.cells].map((c) => c.innerText.trim()))`);
let r = await rows();
t = await panelText();
const keys = r.map((x) => x[0]);
rec('A01', 'Objects tab on m2-objects/target with MAP', 'main.o, sensors/imu.o, libdrv.a(spi.o), libdrv.a(uart.o); Flash descending; remainder line; share column',
  `keys=${JSON.stringify(keys)} first=${JSON.stringify(r[0])} remainder=${t.includes('未归属于任何对象')}`,
  keys.length === 4 && ['main.o', 'sensors/imu.o', 'libdrv.a(spi.o)', 'libdrv.a(uart.o)'].every((k) => keys.includes(k)) && t.includes('未归属于任何对象') && /%/.test(r[0][4] ?? ''));
await shot('A01_objects_target.png');
const uiRows = r;

// A02 sort by RAM (column button named by the sort.by pattern) and by name.
await clickWhere(`() => [...document.querySelectorAll('[role=tabpanel] th button')].find((b) => (b.getAttribute('aria-label') || '').includes('RAM'))`);
await sleep(1200);
const ramAsc = (await rows()).map((x) => x[0]);
await clickWhere(`() => [...document.querySelectorAll('[role=tabpanel] th button')].find((b) => (b.getAttribute('aria-label') || '').includes('对象'))`);
await sleep(1200);
const nameAsc = (await rows()).map((x) => x[0]);
rec('A02', 'Sorting by RAM and by name asks the shell and reorders', 'name order is alphabetical; RAM order differs from the Flash order',
  `ram=${JSON.stringify(ramAsc)} name=${JSON.stringify(nameAsc)}`,
  JSON.stringify(nameAsc) === JSON.stringify([...nameAsc].sort()) && JSON.stringify(ramAsc) !== JSON.stringify(keys));

// A03 filter.
await typeInto(`() => document.querySelector('[role=tabpanel] input[type=text]')`, 'libdrv');
await clickWhere(`() => [...document.querySelectorAll('[role=tabpanel] form button')].find((b) => b.type === 'submit')`);
await sleep(1500);
const filtered = (await rows()).map((x) => x[0]);
rec('A03', 'Filter "libdrv" reaches the shell', 'exactly the two libdrv.a members', JSON.stringify(filtered),
  filtered.length === 2 && filtered.every((k) => k.startsWith('libdrv.a(')));

// A04 Libraries tab.
await openTab('库');
const libs = await rows();
rec('A04', 'Libraries tab', 'one row, libdrv.a, with Flash equal to its two members', JSON.stringify(libs), libs.length === 1 && libs[0][0] === 'libdrv.a');
await shot('A04_libraries.png');

// A06 Compare base(map) -> target(map).
await nav('对比');
await sleep(1500);
const pair = await js(`[...document.querySelectorAll('select')].map((s) => s.options[s.selectedIndex]?.text)`);
await clickWhere(`() => [...document.querySelectorAll('main button')].find((b) => b.textContent.trim() === '对比' && !b.disabled)`);
await sleep(4000);
const regionText = () => js(`document.querySelector('[aria-label="按对象和库查看变化"]')?.innerText ?? ''`);
let rt = await regionText();
const objRows = () => js(`[...(document.querySelector('[aria-label="按对象和库查看变化"] table')?.querySelectorAll('tbody tr') ?? [])].map((r) => [...r.cells].map((c) => c.innerText.trim().replace(/\\s+/g, ' ')))`);
let orows = await objRows();
const spi = orows.find((x) => x[1].startsWith('libdrv.a(spi.o)'));
rec('A06', 'Compare "By object and library" on the m2-objects pair', 'region present; counts line; libdrv.a(spi.o) Added with base "Not present"',
  `pair=${JSON.stringify(pair)} counts=${(rt.match(/对象：[^·\\n]*/) || ['none'])[0]} spi=${JSON.stringify(spi)}`,
  rt.length > 0 && /对象：\d+ 个变化/.test(rt) && spi && spi[0].includes('Added') && spi[2].includes('Not present'));
await shot('A06_compare_objects.png');

// A07 shortlist drill-down: a growth entry filters the table.
const grownKey = await js(`(() => { const b = [...document.querySelectorAll('[aria-label="按对象和库查看变化"] ol button')][0]; return b ? b.getAttribute('aria-label') : null })()`);
await clickWhere(`() => [...document.querySelectorAll('[aria-label="按对象和库查看变化"] ol button')][0]`);
await sleep(1500);
const drilled = (await objRows()).map((x) => x[1]);
rec('A07', 'A shortlist entry filters the object table through the shell', 'the table shows only the picked key', `picked=${grownKey} rows=${JSON.stringify(drilled)}`,
  drilled.length >= 1 && grownKey && drilled.every((k) => grownKey.includes(k.split(' ')[0])));

// A08 Libraries switch.
await clickWhere(`() => [...document.querySelectorAll('[aria-label="按对象和库查看变化"] [role=group] button')].find((b) => b.textContent.trim() === '库')`);
await sleep(1500);
const librows = await objRows();
rec('A08', 'Libraries view of the object changes', 'libdrv.a Changed with a positive Flash delta', JSON.stringify(librows),
  librows.length === 1 && librows[0][1].startsWith('libdrv.a') && librows[0][0].includes('Changed') && /\+/.test(librows[0][4]));

// A09 Overview latest comparison, then back to Compare.
await nav('总览');
const ov = await js(`(() => { const h = [...document.querySelectorAll('h2,h3')].find((e) => e.textContent.trim() === '最近一次比较'); const p = h?.closest('section,div'); return p ? p.innerText : '' })()`);
await shot('A09_overview_latest.png');
await clickWhere(byText('button', '打开比较'));
await sleep(1500);
const onCompare = await js(`!!document.querySelector('[aria-label="按对象和库查看变化"]')`);
rec('A09', 'Overview shows the latest comparison and opens Compare', 'panel with both file names and a signed Flash change; Open Compare returns to the same comparison',
  `panel=${JSON.stringify(ov.slice(0, 200))} backOnCompare=${onCompare}`, ov.includes('firmware.elf') && /[+-]\d/.test(ov) && onCompare);

// A10 minimum window, dark theme: no sideways page scroll on the Objects tab.
await send('Emulation.setDeviceMetricsOverride', { width: 1024, height: 720, deviceScaleFactor: 0, mobile: false });
await send('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-color-scheme', value: 'dark' }] });
await nav('分析');
await openTab('对象');
const overflow = await js(`document.documentElement.scrollWidth > document.documentElement.clientWidth`);
await shot('A10_objects_1024_dark.png');
rec('A10', 'Objects tab at 1024x720 in the dark scheme', 'no sideways page scroll', `pageOverflow=${overflow}`, overflow === false);
await send('Emulation.clearDeviceMetricsOverride');
await send('Emulation.setEmulatedMedia', { features: [] });

writeFileSync(join(QA, 'ui_target_rows.json'), JSON.stringify(uiRows));
ws.close();
process.exit(0);
