﻿param([string]$Exe, [string]$Out, [string]$Fixtures, [ValidateSet('m2', 'armlink')][string]$Kind)
# NEXT-CORE-01 native smoke: the desktop Compare ranking names only sections that cost the device.
# QA-identifier build only; a fresh QA store per run, KEPT under a unique name; the Owner store is only hashed.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.rank-aside-" + (Get-Date -Format "HHmmss")
if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $aside }
$log = @()
$p0 = if ($Kind -eq 'm2') { 'K' } else { 'A' }
function Rec($id, $verdict, $text) { $script:log += "$p0$id`t$verdict`t$text"; "$p0$id $verdict $text" }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Click($name) { node cdp.mjs click $name | Out-Null }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
$file = if ($Kind -eq 'm2') { 'firmware.elf' } else { 'firmware.axf' }
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null
  foreach ($side in 'base', 'target') {
    Click '选择固件镜像文件'
    & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\$file" | Out-Null
    Start-Sleep 1
    if ($Kind -eq 'm2') {
      Click '添加 MAP'
      & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\firmware.map" | Out-Null
      Start-Sleep 1
    }
    Click '分析'
    Start-Sleep 3
  }
  Click '对比 页面'
  Start-Sleep 2
  Click '对比'
  Start-Sleep 4

  $lead = J "[...document.querySelectorAll('section[aria-labelledby]')].map(s => s.textContent).find(x => x.startsWith('Flash 变化'))"
  $flash = if ($Kind -eq 'm2') { '64' } else { '84' }
  $source = if ($Kind -eq 'm2') { 'sensors/imu.o' } else { 'ER_IROM1' }
  Rec '01' (V ($lead -match "▲$flash" -and $lead -match [regex]::Escape($source) -and $lead -notmatch 'symtab')) "lead: $lead"

  $picks = J "(() => { const r = [...document.querySelectorAll('[aria-label]')].find(n => n.getAttribute('aria-label') === '增长最多与新增最大'); return r ? [...r.querySelectorAll('button[aria-label]')].map(b => b.getAttribute('aria-label')).filter(n => n.endsWith('的节变化')).join(' | ') : 'NO_REGION' })()"
  $want = if ($Kind -eq 'm2') { '.text' } else { 'ER_IROM1' }
  Rec '02' (V ($picks -match [regex]::Escape($want) -and $picks -notmatch 'symtab|strtab|debug|comment|RW_IRAM1|ARM\.attributes')) "section picks in the ranking: $picks"

  $note = J "(() => { const r = [...document.querySelectorAll('[aria-label]')].find(n => n.getAttribute('aria-label') === '增长最多与新增最大'); return [...r.querySelectorAll('p')].map(p => p.textContent).find(t => t.startsWith('未作为占用设备的节参与排名')) ?? 'NO_NOTE' })()"
  $noteOk = if ($Kind -eq 'm2') { $note -match '2 个主机元数据节' } else { $note -match '4 个主机元数据节' -and $note -match '2 个名称重复的新增节' }
  Rec '03' (V $noteOk) "left-out note: $note"
  node cdp.mjs shot "$Out\$Kind-01-ranking.png" | Out-Null

  Click '节'
  Start-Sleep 2
  $table = J "(() => { const t = document.querySelector('[role=tabpanel]'); return t ? [...t.querySelectorAll('tbody tr')].map(r => r.textContent.slice(0, 40)).join(' | ') : null })()"
  Rec '04' (V ($table -match 'symtab')) "the full Sections view still holds the metadata rows: $table"
  Click '概要'
  Start-Sleep 1

  $md = Join-Path $Out "$Kind-comparison.md"
  Click '导出'
  Start-Sleep 1
  Click '导出 Markdown'
  $d = & .\dialog.ps1 -ProcId $p.Id -FilePath $md
  Start-Sleep 2
  $doc = if (Test-Path $md) { Get-Content -Raw -Encoding utf8 $md } else { '' }
  $section = if ($doc.Contains('Top growth, sections that cost the device')) { $doc.Substring($doc.IndexOf('Top growth, sections that cost the device')) } else { '' }
  $section = ($section -split "`n### ")[0]
  # Markdown escapes `_` (ER_IROM1 is written ER\_IROM1), so the name is looked for as it is written.
  $wantMd = $want.Replace('_', '\_')
  Rec '05' (V ($section.Contains($wantMd) -and $section -notmatch 'symtab' -and $doc -match 'host-metadata')) "Compare > Export Markdown ($d): ranking agrees with the screen; note present"

  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.rank-$Kind-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  if (Test-Path "$a\$aside") { Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa" }
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec '06' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
$log | Set-Content -Encoding utf8 "$Out\$Kind-results.tsv"
