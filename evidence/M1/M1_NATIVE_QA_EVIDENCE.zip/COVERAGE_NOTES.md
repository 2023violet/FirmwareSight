# What this evidence does and does not show (revision 2, after independent review)

- `pass.sh` ran C01–C22 in one pass on code SHA 2b0f933. C11 and C20 FAILED on that first attempt
  (the script truncated the alert text; the harness could not take the foreground). They were re-run by
  hand with the commands in `drivers/followups.sh`; their raw output is `raw_C11_rerun_stdout.txt` and
  `raw_C20_rerun_uia.txt`. C23–C25 were also run by hand from the same file. Both results were appended
  to results.jsonl afterwards, which is why C11-rerun and C20-rerun share a timestamp.
- Overwrite deny, confirm, write failure and retry (C08–C12) were all driven through the Compare JSON
  export. The visual export paths (PNG/SVG/print HTML) were exercised for normal save and staleness
  only (C13, C14, C16–C18).
- The English replace confirmation was not opened; only the English Save dialog was (C21).
- Tab / Shift-Tab traversal and the focus ring were observed during exploration but are not recorded in
  this pass. The keyboard case on record is C19 (Enter opens Save, Esc cancels, focus returns).
- No screen reader was used; C20 reads UI Automation only.
- Window sizes on record: 1040x760 and 1024x720. 1440x900 was not captured. Only the Compare table's
  horizontal overflow was measured (C05).
- Write failure was simulated with a share-locked target, not a non-writable directory.
- The register's minimum environment (a dedicated non-Owner Windows profile) and a human operator were
  not used: the operator was an automated driver on the Owner's profile, isolated by a separate app
  identifier, with the Owner's app data hashed identical before and after (C24).
- Native drag-and-drop (C25) is NOT_RUN.
