#!/usr/bin/env bash
# M1 native QA evidence pass on the final QA build. Writes results.jsonl and shots/final_*.png.
# Usage: pass.sh <pid>
set -u
export PYTHONIOENCODING=utf-8
Q="$(cd "$(dirname "$0")" && pwd)"; cd "$Q"
PID="$1"
OUT="$Q/out2"; OUTW="$(cygpath -w "$OUT")"; INW="$(cygpath -w "$Q/in")"; PRJW="$(cygpath -w "$Q/project")"
RES="$Q/results.jsonl"; : > "$RES"
mkdir -p "$OUT" shots
W(){ QA_OUT="$(cygpath -w "$Q/w.json")" pwsh -NoProfile -File win.ps1 "$@" -ProcessId "$PID" >/dev/null 2>&1; }
DLG(){ QA_OUT="$(cygpath -w "$Q/list.json")" pwsh -NoProfile -File win.ps1 -Action list -ProcessId "$PID" >/dev/null 2>&1; python -I show.py list.json list.txt; cat list.txt; }
J(){ node cdp.mjs eval "$1" 2>/dev/null | python -I -c "import sys,json;print(json.loads(sys.stdin.read() or 'null'))" 2>/dev/null; }
CLICKJS(){ J "(()=>{const b=[...document.querySelectorAll('main button')].find(x=>x.textContent.trim()==='$1'); if(!b) return 'missing'; b.click(); return 'ok'})()" >/dev/null; }
NAV(){ node cdp.mjs click "$1" button >/dev/null 2>&1; sleep 1.5; }
MAINTXT(){ J "document.querySelector('main').innerText"; }
rec(){ python -I - "$RES" "$1" "$2" "$3" "$4" "$5" <<'EOF'
import json,sys,datetime
p,cid,title,expected,actual,verdict=sys.argv[1:]
open(p,'a',encoding='utf-8').write(json.dumps({"case":cid,"title":title,"expected":expected,"actual":actual,"verdict":verdict,"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')},ensure_ascii=False)+"\n")
print(cid,verdict,'-',actual[:140])
EOF
}
ok(){ if [ "${1:-0}" = 1 ]; then echo PASS; else echo FAIL; fi; }

# C01 / C02 picker title and cancel
NAV "分析 页面"; node cdp.mjs click "选择固件镜像文件" button >/dev/null; sleep 2; T="$(DLG | head -1)"
rec C01 "Native picker title follows UI language (zh)" "#32770 选择要分析的固件文件" "$T" "$(ok $([[ "$T" == *选择要分析的固件文件* ]] && echo 1))"
W -Action click -Title "选择要分析的固件文件" -Id 2; sleep 1; A="$(J "document.querySelectorAll('[role=alert]').length")"; S="$(MAINTXT | grep -c '已选择' || true)"
rec C02 "Cancel picker: no selection, no error" "0 alerts, nothing selected" "alerts=$A selectedLines=$S" "$(ok $([ "$A" = 0 ] && [ "$S" = 0 ] && echo 1))"

# C03 pick base ELF + MAP, analyze
node cdp.mjs click "选择固件镜像文件" button >/dev/null; sleep 2; W -Action settext -Title "选择要分析的固件文件" -Id 1148 -Text "$INW\\base\\app.elf"; W -Action click -Title "选择要分析的固件文件" -Id 1; sleep 2
node cdp.mjs click "添加 MAP" button >/dev/null; sleep 2; T="$(DLG | head -1)"; W -Action settext -Title "选择这个固件的链接器 MAP 文件" -Id 1148 -Text "$INW\\base\\app.map"; W -Action click -Title "选择这个固件的链接器 MAP 文件" -Id 1; sleep 2
CLICKJS "分析"; sleep 3; node cdp.mjs shot shots/final_03_analyze.png >/dev/null
M="$(MAINTXT | grep -o '可用于硬性预算\|MAP provided' | head -2 | tr '\n' ' ')"
rec C03 "Choose ELF and MAP in native dialogs, analyze" "MAP picker titled in zh; analysis shows evidence quality" "mapPicker=[$T] result=[$M]" "$(ok $([[ "$T" == *MAP* && "$M" == *可用于硬性预算* ]] && echo 1))"

# C04 overview bars
NAV "总览 页面"; J "(()=>{const m=document.querySelector('[role=meter]'); m&&m.scrollIntoView({block:'center'}); return 1})()" >/dev/null; node cdp.mjs shot shots/final_04_overview_bars.png >/dev/null
V="$(J "[...document.querySelectorAll('[role=meter]')].map(e=>e.getAttribute('aria-label')+'='+e.getAttribute('aria-valuetext')).join(' | ')")"
rec C04 "Overview memory bars, tiny usage not shown as 0.0%" "ROM and RAM meters, '<0.1%'" "$V" "$(ok $([[ "$V" == *"<0.1%"* ]] && echo 1))"

# C05 analyze target and compare
NAV "分析 页面"; node cdp.mjs click "选择固件镜像文件" button >/dev/null; sleep 2; W -Action settext -Title "选择要分析的固件文件" -Id 1148 -Text "$INW\\target\\app.elf"; W -Action click -Title "选择要分析的固件文件" -Id 1; sleep 2
node cdp.mjs click "添加 MAP" button >/dev/null; sleep 2; W -Action settext -Title "选择这个固件的链接器 MAP 文件" -Id 1148 -Text "$INW\\target\\app.map"; W -Action click -Title "选择这个固件的链接器 MAP 文件" -Id 1; sleep 2
CLICKJS "分析"; sleep 3; NAV "对比 页面"; J "(()=>{[...document.querySelectorAll('main button')].find(x=>x.textContent.trim()==='对比').click(); return 1})()" >/dev/null; sleep 3
TB="$(J "(()=>{const v=document.querySelector('table')?.closest('[role=group]'); return v? (v.scrollWidth>v.clientWidth)+'/'+(document.documentElement.scrollWidth>document.documentElement.clientWidth):'none'})()")"
node cdp.mjs shot shots/final_05_compare.png >/dev/null
rec C05 "Compare two analyzed builds; wide table scrolls in its own box" "table wider than box (true), page not wider (false)" "$TB" "$(ok $([ "$TB" = "true/false" ] && echo 1))"

save_json(){ node cdp.mjs click "导出 JSON" button >/dev/null; sleep 2; W -Action settext -Title "将构建差异保存为 JSON" -Id 1001 -Text "$OUTW\\$1"; W -Action click -Title "将构建差异保存为 JSON" -Id 1; sleep 2; }
NOTE(){ J "((document.querySelector('main').innerText.match(/已写入[^\n]*|取消导出[^\n]*|保留了[^\n]*|没有写入任何文件[^\n]*/)||['none'])[0])"; }

# C06 normal save
node cdp.mjs click "导出 JSON" button >/dev/null; sleep 2; T="$(DLG | grep -E '#32770|导出文件' | tr '\n' ' ')"; W -Action settext -Title "将构建差异保存为 JSON" -Id 1001 -Text "$OUTW\\diff.json"; W -Action click -Title "将构建差异保存为 JSON" -Id 1; sleep 2
V="$(python -I -c "import json;d=json.load(open(r'$OUTW\\diff.json',encoding='utf-8'));print(d['schema'])" 2>&1)"; P="$(grep -c 'Users\\\\\|LOCAL_USER' "$OUT/diff.json")"; N="$(NOTE)"
rec C06 "Native Save writes a valid JSON with no host path" "zh title+filter, schema present, 0 path hits, written note" "dialog=[$T] schema=$V pathHits=$P note=$N" "$(ok $([[ "$T" == *JSON\ 导出文件* && "$V" == urn:* && "$P" = 0 && "$N" == 已写入* ]] && echo 1))"

# C07 cancel save
ls "$OUT" > before.txt; node cdp.mjs click "导出 JSON" button >/dev/null; sleep 2; W -Action click -Title "将构建差异保存为 JSON" -Id 2; sleep 1; D="$(ls "$OUT" | diff before.txt - | wc -l)"; N="$(NOTE)"
rec C07 "Cancel Save writes nothing" "no new files; cancelled note" "newFiles=$D note=$N" "$(ok $([ "$D" = 0 ] && [[ "$N" == 取消导出* ]] && echo 1))"

# C08 deny at OS overwrite prompt
printf 'S8\n' > "$OUT/s8.json"; H="$(sha256sum "$OUT/s8.json" | cut -c1-64)"; save_json s8.json; P="$(DLG | grep -c 确认另存为)"; W -Action click -Title "确认另存为" -Text "否(&N)"; sleep 1; W -Action click -Title "将构建差异保存为 JSON" -Id 2; sleep 1
H2="$(sha256sum "$OUT/s8.json" | cut -c1-64)"
rec C08 "Refuse overwrite at the OS prompt" "OS prompt shown; sentinel bytes unchanged" "osPrompt=$P same=$([ "$H" = "$H2" ] && echo yes || echo no)" "$(ok $([ "$P" -ge 1 ] && [ "$H" = "$H2" ] && echo 1))"

# C09 deny at app confirmation
printf 'S9\n' > "$OUT/s9.json"; H="$(sha256sum "$OUT/s9.json" | cut -c1-64)"; save_json s9.json; W -Action click -Title "确认另存为" -Text "是(&Y)"; sleep 2; C="$(DLG | grep -E '替换已有文件|替换$|保留原文件' | tr '\n' ' ')"; W -Action click -Title "替换已有文件？" -Text "保留原文件"; sleep 2
H2="$(sha256sum "$OUT/s9.json" | cut -c1-64)"; N="$(NOTE)"
rec C09 "Refuse overwrite at the app's localized confirmation" "zh title/buttons; sentinel unchanged; kept note" "confirm=[$C] same=$([ "$H" = "$H2" ] && echo yes || echo no) note=$N" "$(ok $([[ "$C" == *保留原文件* ]] && [ "$H" = "$H2" ] && [[ "$N" == 保留了* ]] && echo 1))"

# C10 confirm overwrite
printf 'S10\n' > "$OUT/s10.json"; printf 'NB\n' > "$OUT/nb.txt"; NB="$(sha256sum "$OUT/nb.txt" | cut -c1-64)"; save_json s10.json; W -Action click -Title "确认另存为" -Text "是(&Y)"; sleep 2; W -Action click -Title "替换已有文件？" -Text "替换"; sleep 2
R="$(head -c 20 "$OUT/s10.json")"; NB2="$(sha256sum "$OUT/nb.txt" | cut -c1-64)"; TMP="$(ls -a "$OUT" | grep -c '\.tmp-')"
rec C10 "Confirm overwrite replaces only the target" "target is the diff JSON; neighbour unchanged; no temp file" "head=$R neighbourSame=$([ "$NB" = "$NB2" ] && echo yes || echo no) temps=$TMP" "$(ok $([[ "$R" == '{"schema"'* ]] && [ "$NB" = "$NB2" ] && [ "$TMP" = 0 ] && echo 1))"

# C11 write failure (target locked by another process)
printf 'S11\n' > "$OUT/s11.json"; H="$(sha256sum "$OUT/s11.json" | cut -c1-64)"
pwsh -NoProfile -Command "\$f=[IO.File]::Open('$OUTW\\s11.json','Open','Read','None'); Start-Sleep -Seconds 40; \$f.Close()" & LOCK=$!
sleep 2; save_json s11.json; W -Action click -Title "确认另存为" -Text "是(&Y)"; sleep 2; W -Action click -Title "替换已有文件？" -Text "替换"; sleep 3
E="$(J "(()=>{const a=document.querySelector('[role=alert]'); return a? a.innerText.replace(/\n/g,' | ').slice(0,260):'no alert'})()")"; node cdp.mjs shot shots/final_11_write_failure.png >/dev/null; wait $LOCK
H2="$(sha256sum "$OUT/s11.json" | cut -c1-64)"; TMP="$(ls -a "$OUT" | grep -c '\.tmp-')"
rec C11 "A write failure is reported, the target is untouched, no temp is left" "ERR-EXPORT-6001 with diagnostics id; bytes unchanged; no temp" "alert=$E same=$([ "$H" = "$H2" ] && echo yes || echo no) temps=$TMP" "$(ok $([[ "$E" == *ERR-EXPORT-6001*op-* ]] && [ "$H" = "$H2" ] && [ "$TMP" = 0 ] && echo 1))"

# C12 retry clears the error
save_json retry.json; A="$(J "document.querySelectorAll('[role=alert]').length")"; N="$(NOTE)"
rec C12 "Retry after failure succeeds and clears the error" "0 alerts; written note" "alerts=$A note=$N" "$(ok $([ "$A" = 0 ] && [[ "$N" == 已写入* ]] && echo 1))"

# C13 compare stale
node cdp.mjs click "导出 PNG" button >/dev/null; sleep 2; J "(()=>{[...document.querySelectorAll('main button')].find(x=>x.textContent.trim()==='交换').click(); return 1})()" >/dev/null; sleep 1; J "(()=>{[...document.querySelectorAll('main button')].find(x=>x.textContent.trim()==='对比').click(); return 1})()" >/dev/null; sleep 3
W -Action settext -Title "保存对比报告" -Id 1001 -Text "$OUTW\\stale_compare.png"; W -Action click -Title "保存对比报告" -Id 1; sleep 3
F="$([ -e "$OUT/stale_compare.png" ] && echo written || echo absent)"; N="$(NOTE)"
rec C13 "Compare changed while Save was open: refused, and the screen says so" "file absent; 'nothing was written' note" "file=$F note=$N" "$(ok $([ "$F" = absent ] && [[ "$N" == *没有写入任何文件* ]] && echo 1))"

# C14 analyze stale
NAV "分析 页面"; node cdp.mjs click "导出 PNG" button >/dev/null; sleep 2; node cdp.mjs click "选择固件镜像文件" button >/dev/null; sleep 2
W -Action settext -Title "选择要分析的固件文件" -Id 1148 -Text "$INW\\basic\\firmware.elf"; W -Action click -Title "选择要分析的固件文件" -Id 1; sleep 2
W -Action settext -Title "保存分析报告" -Id 1001 -Text "$OUTW\\stale_analyze.png"; W -Action click -Title "保存分析报告" -Id 1; sleep 3
F="$([ -e "$OUT/stale_analyze.png" ] && echo written || echo absent)"; N="$(NOTE)"
rec C14 "Analysis changed while Save was open: refused, and the screen says so" "file absent; note" "file=$F note=$N" "$(ok $([ "$F" = absent ] && [[ "$N" == *没有写入任何文件* ]] && echo 1))"

# C15 gate: project, run with a real (CDP mouse) click, focus on verdict
NAV "发布门禁 页面"; node cdp.mjs click "打开工程配置" button >/dev/null; sleep 2; W -Action settext -Title "选择项目的 firmwaresight.toml" -Id 1148 -Text "$PRJW\\firmwaresight.toml"; W -Action click -Title "选择项目的 firmwaresight.toml" -Id 1; sleep 2
TOP="$(J "(()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim()==='运行 Gate'); b.scrollIntoView({block:'nearest'}); const r=b.getBoundingClientRect(); const t=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2); return (t===b||b.contains(t))?'on top':'covered by '+t.tagName})()")"
node cdp.mjs click "运行 Gate" button >/dev/null; sleep 3; FO="$(J "(document.activeElement.getAttribute('aria-label')||document.activeElement.tagName)")"; node cdp.mjs shot shots/final_15_gate.png >/dev/null
rec C15 "Run Gate with a real mouse click; focus moves to the verdict" "button on top; focus on the verdict region" "button=$TOP focus=$FO" "$(ok $([ "$TOP" = "on top" ] && [ "$FO" = "门禁结论" ] && echo 1))"

# C16 gate stale
J "(()=>{[...document.querySelectorAll('main button')].find(x=>x.textContent.trim()==='导出 PNG').click(); return 1})()" >/dev/null; sleep 2
# A different run: choose the other stored build as baseline, then judge again (identical inputs give the same run id).
J "(()=>{const s=document.getElementById('fs-gate-baseline'); const v=[...s.options].map(o=>o.value).find(v=>v!==''); const set=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set; set.call(s,v); s.dispatchEvent(new Event('change',{bubbles:true})); return v})()" >/dev/null; sleep 1
RID1="$(J "(document.querySelector('main').innerText.match(/gate-[0-9a-f]{3}/)||[''])[0]")"
J "(()=>{[...document.querySelectorAll('button')].find(x=>x.textContent.trim()==='运行 Gate').click(); return 1})()" >/dev/null; sleep 3
W -Action settext -Title "保存发布门禁审查报告" -Id 1001 -Text "$OUTW\\stale_gate.png"; W -Action click -Title "保存发布门禁审查报告" -Id 1; sleep 3
F="$([ -e "$OUT/stale_gate.png" ] && echo written || echo absent)"; N="$(J "((document.querySelector('main').innerText.match(/[^\n]*没有写入任何文件[^\n]*/)||['none'])[0])")"
rec C16 "Gate run changed while Save was open: refused, and the screen says so" "file absent; note" "file=$F note=$N" "$(ok $([ "$F" = absent ] && [[ "$N" == *没有写入任何文件* ]] && echo 1))"

# C17 gate HTML export
J "(()=>{[...document.querySelectorAll('main button')].find(x=>x.textContent.trim()==='导出可打印 HTML').click(); return 1})()" >/dev/null; sleep 2; T="$(DLG | grep -E '#32770|报告' | tr '\n' ' ')"
W -Action settext -Title "保存发布门禁审查报告" -Id 1001 -Text "$OUTW\\gate.html"; W -Action click -Title "保存发布门禁审查报告" -Id 1; sleep 3
S="$(grep -ci '<script' "$OUT/gate.html")"; P="$(grep -c 'Users\\\\\|LOCAL_USER' "$OUT/gate.html")"
rec C17 "Gate print-ready HTML via native Save" "zh title/filter; no script; no path" "dialog=[$T] scripts=$S paths=$P bytes=$(wc -c < "$OUT/gate.html")" "$(ok $([[ "$T" == *HTML\ 报告* ]] && [ "$S" = 0 ] && [ "$P" = 0 ] && echo 1))"

# C18 compare PNG + SVG decode
NAV "对比 页面"; for f in PNG SVG; do node cdp.mjs click "导出 $f" button >/dev/null; sleep 2; W -Action settext -Title "保存对比报告" -Id 1001 -Text "$OUTW\\compare.${f,,}"; W -Action click -Title "保存对比报告" -Id 1; sleep 3; done
D="$(python -I - "$OUTW" <<'EOF'
import sys,struct,zlib,os,xml.dom.minidom
d=sys.argv[1]; b=open(os.path.join(d,'compare.png'),'rb').read(); ok=b[:8]==b'\x89PNG\r\n\x1a\n'; i=8
while i<len(b):
    ln=struct.unpack('>I',b[i:i+4])[0]; t=b[i+4:i+8]; ok&=(zlib.crc32(t+b[i+8:i+8+ln])&0xffffffff)==struct.unpack('>I',b[i+8+ln:i+12+ln])[0]; i+=12+ln
w,h=struct.unpack('>II',b[16:24]); s=open(os.path.join(d,'compare.svg'),encoding='utf-8').read(); xml.dom.minidom.parseString(s)
print(f"png {w}x{h} crc={ok} svg-parsed script={'<script' in s.lower()}")
EOF
)"
rec C18 "Visual exports decode independently" "PNG 1600x900 CRC ok; SVG parses; no script" "$D" "$(ok $([[ "$D" == "png 1600x900 crc=True svg-parsed script=False" ]] && echo 1))"

# C19 keyboard: Enter opens Save, Esc cancels, focus returns
J "(()=>{[...document.querySelectorAll('main button')].find(x=>x.textContent.trim()==='导出 SVG').focus(); return 1})()" >/dev/null; node cdp.mjs key Enter >/dev/null; sleep 2; O="$(DLG | grep -c '保存对比报告')"
pwsh -NoProfile -File esc.ps1 -Title "保存对比报告" >/dev/null; sleep 2; C="$(DLG | grep -c '#32770')"; FO="$(J "document.activeElement.textContent.trim()")"; N="$(NOTE)"
rec C19 "Keyboard: Enter opens the native Save, Esc cancels, focus returns to the control" "dialog opened; closed; focus on 导出 SVG; cancelled note" "opened=$O openAfterEsc=$C focus=$FO note=$N" "$(ok $([ "$O" -ge 1 ] && [ "$C" = 0 ] && [ "$FO" = "导出 SVG" ] && [[ "$N" == 取消导出* ]] && echo 1))"

# C20 UI Automation exposes the focused control
pwsh -NoProfile -File fg.ps1 -ProcessId "$PID" >/dev/null; sleep 1; J "(()=>{[...document.querySelectorAll('main button')].find(x=>x.textContent.trim()==='导出 SVG').focus(); return 1})()" >/dev/null; sleep 1
QA_OUT="$(cygpath -w "$Q/uia.json")" pwsh -NoProfile -File win.ps1 -Action focused >/dev/null 2>&1; U="$(python -I -c "import json;d=json.load(open(r'$(cygpath -w "$Q/uia.json")',encoding='utf-8-sig'));print(d['controlType'],'|',d['name'],'|',d['keyboardFocusable'])")"
rec C20 "Windows UI Automation sees the focused control's role and name" "ControlType.Button | 导出 SVG | True" "$U" "$(ok $([[ "$U" == "ControlType.Button | 导出 SVG | True" ]] && echo 1))"

# C21 English mode: native titles follow
NAV "设置 页面"; J "(()=>{[...document.querySelectorAll('label')].find(x=>x.textContent.trim()==='English').click(); return 1})()" >/dev/null; sleep 2
NAV "Compare page"; node cdp.mjs click "Export JSON" button >/dev/null; sleep 2; T="$(DLG | grep -E '#32770|export' | tr '\n' ' ')"; W -Action click -Title "Save the build diff as JSON" -Id 2; sleep 1
rec C21 "English UI: native Save title and filter in English" "Save the build diff as JSON; FirmwareSight JSON export" "$T" "$(ok $([[ "$T" == *"Save the build diff as JSON"* && "$T" == *"FirmwareSight JSON export"* ]] && echo 1))"
NAV "Settings page"; J "(()=>{[...document.querySelectorAll('label')].find(x=>x.textContent.trim()==='简体中文').click(); return 1})()" >/dev/null; sleep 1

# C22 dark theme at the minimum window size
J "(()=>{[...document.querySelectorAll('label')].find(x=>x.textContent.trim()==='深色').click(); return 1})()" >/dev/null; sleep 1
W -Action resize -Title "FirmwareSight - Settings" -Width 1024 -Height 720; sleep 2; R=""
for p in "总览 页面:overview" "分析 页面:analyze" "对比 页面:compare" "发布门禁 页面:release" "发布包与历史 页面:history" "设置 页面:settings"; do NAV "${p%%:*}"; node cdp.mjs shot "shots/final_22_dark_1024_${p##*:}.png" >/dev/null; R="$R ${p##*:}=$(J "document.documentElement.scrollWidth>document.documentElement.clientWidth")"; done
rec C22 "Dark theme at 1024x720: no page scrolls sideways (screenshots kept)" "every page false" "$R" "$(ok $([[ "$R" != *true* ]] && echo 1))"
J "(()=>{[...document.querySelectorAll('label')].find(x=>x.textContent.trim()==='浅色').click(); return 1})()" >/dev/null
