param([int]$ProcessId, [string[]]$Files, [string]$Out)
# Real OLE drag-and-drop driven entirely from compiled C#, so the timer that moves the mouse runs inside
# DoDragDrop's own message loop (a PowerShell script block cannot run there).
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @'
using System; using System.Drawing; using System.Runtime.InteropServices; using System.Windows.Forms;
using System.Collections.Specialized;
public class DragSource : Form {
  [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] static extern void mouse_event(uint f, uint dx, uint dy, uint d, IntPtr e);
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  Timer timer = new Timer(); int step; int sx, sy, tx, ty; DataObject data; public string Result = "none";
  public DragSource(IntPtr target, string[] files) {
    RECT r; GetWindowRect(target, out r); tx = (r.L + r.R) / 2; ty = (r.T + r.B) / 2;
    StartPosition = FormStartPosition.Manual; Location = new Point(Math.Max(0, r.L - 230), r.T + 40); Size = new Size(200, 120); TopMost = true; Text = "drag-source";
    sx = Location.X + 100; sy = Location.Y + 60;
    data = new DataObject(); var list = new StringCollection(); list.AddRange(files); data.SetFileDropList(list);
    timer.Interval = 50;
    timer.Tick += (s, e) => {
      step++; const int n = 24;
      if (step <= n) { SetCursorPos(sx + (tx - sx) * step / n, sy + (ty - sy) * step / n); mouse_event(0x0001, 0, 0, 0, IntPtr.Zero); }
      else if (step == n + 10) { mouse_event(0x0004, 0, 0, 0, IntPtr.Zero); }
    };
    Shown += (s, e) => {
      Activate(); SetCursorPos(sx, sy); mouse_event(0x0002, 0, 0, 0, IntPtr.Zero); Application.DoEvents();
      timer.Start();
      Result = DoDragDrop(data, DragDropEffects.Copy).ToString();
      timer.Stop(); mouse_event(0x0004, 0, 0, 0, IntPtr.Zero); Close();
    };
  }
}
'@
$target = (Get-Process -Id $ProcessId).MainWindowHandle
$form = [DragSource]::new($target, [string[]]$Files)
[void]$form.ShowDialog()
Set-Content -LiteralPath $Out -Value ("drop result: " + $form.Result)
