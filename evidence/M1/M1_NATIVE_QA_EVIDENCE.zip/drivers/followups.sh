#!/usr/bin/env bash
# The commands run after pass.sh ended at C22, reconstructed from the session transcript in the order run.
# They were run by hand, not as one script; results were appended to results.jsonl afterwards, which is
# why C11-rerun and C20-rerun carry the same timestamp. PID is the running QA app, OUT the scratch output dir.

# C11-rerun: write failure, capturing code and diagnostics id (pass.sh truncated the alert at 260 chars)
printf 'S11b\n' > "$OUT/s11b.json"; H="$(sha256sum "$OUT/s11b.json" | cut -c1-64)"
pwsh -NoProfile -Command "\$f=[IO.File]::Open('$OUTW\s11b.json','Open','Read','None'); Start-Sleep -Seconds 40; \$f.Close()" & LOCK=$!
sleep 2; node cdp.mjs click "导出 JSON" button; sleep 2
W -Action settext -Title "将构建差异保存为 JSON" -Id 1001 -Text "$OUTW\s11b.json"; W -Action click -Title "将构建差异保存为 JSON" -Id 1; sleep 2
W -Action click -Title "确认另存为" -Text "是(&Y)"; sleep 2; W -Action click -Title "替换已有文件？" -Text "替换"; sleep 3
node cdp.mjs eval "(()=>{const a=document.querySelector('[role=alert]'); return a? [a.innerText.match(/ERR-EXPORT-\d+/)?.[0], a.innerText.match(/op-[0-9a-f-]+/)?.[0]].join(' '):'no alert'})()"
wait $LOCK; H2="$(sha256sum "$OUT/s11b.json" | cut -c1-64)"; echo "same=$([ "$H" = "$H2" ] && echo yes || echo no) temps=$(ls -a "$OUT" | grep -c '\.tmp-')"

# C20-rerun: up to three tries of foreground + focus + UI Automation read (first try in pass.sh read a Pane
# because the harness could not take the foreground after C19's Esc)
for i in 1 2 3; do pwsh -NoProfile -File fg.ps1 -ProcessId $PID; sleep 1; node cdp.mjs click "对比 页面" button; sleep 1
  node cdp.mjs eval "(()=>{[...document.querySelectorAll('main button')].find(x=>x.textContent.trim()==='导出 SVG').focus(); return 1})()"; sleep 1
  QA_OUT=uia.json pwsh -NoProfile -File win.ps1 -Action focused; grep -q Button uia.json && break; done

# C23: restart the same build and count History rows
taskkill //PID $PID; sleep 3; # relaunch with the DevTools port as before, then:
node cdp.mjs click "发布包与历史 页面" button; sleep 2; node cdp.mjs eval "document.querySelectorAll('main table tbody tr').length"

# C24: Owner app data, read-only hash list compared with the list taken before QA
(cd "$APPDATA/com.firmwaresight.desktop" && find . -type f -exec sha256sum {} \; | sort -k2) > owner_appdata_after.sha256
diff owner_appdata_before.sha256 owner_appdata_after.sha256 | wc -l

# C25: native drag-and-drop - three attempts with drag.ps1 / drag2.ps1 (WinForms DoDragDrop + SendInput)
# never produced a drop on the window; recorded NOT_RUN.
