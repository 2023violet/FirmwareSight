﻿param(
  [Parameter(Mandatory = $true)][string]$Action,
  [int]$ProcessId,
  [string]$Title = '',
  [string]$Text = '',
  [int]$Id = 0,
  [int]$Width = 0,
  [int]$Height = 0
)
# Win32 / UI Automation helper for M1 native QA. Read-mostly; it only types into and clicks controls of
# windows owned by the QA process id it is given.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
public static class W {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr SendMessageTimeoutW(IntPtr h, uint m, IntPtr w, string l, uint f, uint t, out IntPtr r);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeoutW(IntPtr h, uint m, IntPtr w, IntPtr l, uint f, uint t, out IntPtr r);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr SendMessageW(IntPtr h, uint m, IntPtr w, StringBuilder l);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int cx, int cy, uint f);
  [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  public static string Text(IntPtr h) { var s = new StringBuilder(1024); GetWindowText(h, s, 1024); if (s.Length == 0) { var b = new StringBuilder(2048); SendMessageW(h, 0x000D, (IntPtr)2048, b); return b.ToString(); } return s.ToString(); }
  public static string Cls(IntPtr h) { var s = new StringBuilder(256); GetClassName(h, s, 256); return s.ToString(); }
  public static List<IntPtr> Tops(uint pid) { var r = new List<IntPtr>(); EnumWindows((h, l) => { uint p; GetWindowThreadProcessId(h, out p); if (p == pid && IsWindowVisible(h)) r.Add(h); return true; }, IntPtr.Zero); return r; }
  public static List<IntPtr> Kids(IntPtr p) { var r = new List<IntPtr>(); EnumChildWindows(p, (h, l) => { r.Add(h); return true; }, IntPtr.Zero); return r; }
}
'@

function Find-Window([string]$t) {
  foreach ($h in [W]::Tops([uint32]$ProcessId)) {
    if ($t -eq '' -or [W]::Text($h) -eq $t) { return $h }
  }
  return [IntPtr]::Zero
}

$result = switch ($Action) {
  'list' { $rows = @(
    foreach ($h in [W]::Tops([uint32]$ProcessId)) {
      [pscustomobject]@{ hwnd = $h.ToInt64(); class = [W]::Cls($h); title = [W]::Text($h) }
      if ([W]::Cls($h) -eq '#32770') {
        foreach ($k in [W]::Kids($h)) {
          if ([W]::IsWindowVisible($k)) {
            [pscustomobject]@{ hwnd = $k.ToInt64(); class = '  ' + [W]::Cls($k); id = [W]::GetDlgCtrlID($k); title = [W]::Text($k) }
          }
        }
      }
    }
    ) ; $rows
  }
  'settext' {
    $d = Find-Window $Title; if ($d -eq [IntPtr]::Zero) { throw "no visible window titled '$Title'" }
    $target = [W]::Kids($d) | Where-Object { [W]::Cls($_) -eq 'Edit' -and ([W]::GetDlgCtrlID($_) -eq $Id) } | Select-Object -First 1
    if ($null -eq $target) { throw "no Edit with id $Id" }
    $r = [IntPtr]::Zero
    [void][W]::SendMessageTimeoutW($target, 0x000C, [IntPtr]::Zero, $Text, 2, 3000, [ref]$r)
    "set $Id"
  }
  'click' {
    $d = Find-Window $Title; if ($d -eq [IntPtr]::Zero) { throw "no visible window titled '$Title'" }
    $btn = [W]::Kids($d) | Where-Object { [W]::Cls($_) -eq 'Button' -and (($Id -ne 0 -and [W]::GetDlgCtrlID($_) -eq $Id) -or ($Text -ne '' -and [W]::Text($_) -eq $Text)) } | Select-Object -First 1
    if ($null -eq $btn) { throw "no button id=$Id text='$Text'" }
    [void][W]::PostMessageW($btn, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero)
    "clicked " + [W]::Text($btn)
  }
  'resize' {
    $m = Find-Window $Title; if ($m -eq [IntPtr]::Zero) { throw "no main window" }
    [void][W]::SetWindowPos($m, [IntPtr]::Zero, 40, 40, $Width, $Height, 0x0004)
    "resized"
  }
  'focused' {
    Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
    $e = [System.Windows.Automation.AutomationElement]::FocusedElement
    [pscustomobject]@{
      name = $e.Current.Name; controlType = $e.Current.ControlType.ProgrammaticName
      pid = $e.Current.ProcessId; class = $e.Current.ClassName; enabled = $e.Current.IsEnabled
      keyboardFocusable = $e.Current.IsKeyboardFocusable
    }
  }
  default { throw "unknown action $Action" }
}

if ($env:QA_OUT) { $result | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $env:QA_OUT -Encoding utf8 } else { $result | ConvertTo-Json -Depth 3 }
