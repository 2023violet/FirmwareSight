param([int]$ProcessId)
Add-Type -Name F -Namespace N -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);'
[void][N.F]::SetForegroundWindow((Get-Process -Id $ProcessId).MainWindowHandle); "fg"
