param([string]$Title)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Name F -Namespace N -MemberDefinition '[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindowW(string c, string t); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);'
$h = [N.F]::FindWindowW('#32770', $Title)
[void][N.F]::SetForegroundWindow($h); Start-Sleep -Milliseconds 400
[System.Windows.Forms.SendKeys]::SendWait('{ESC}')
"esc sent to $h"
