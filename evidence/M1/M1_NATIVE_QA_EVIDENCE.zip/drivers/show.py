import json,sys
d=json.load(open(sys.argv[1],encoding='utf-8-sig'))
d=d if isinstance(d,list) else [d]
out=[]
for r in d:
    c=(r.get('class') or '').strip()
    if c in ('#32770','Static','Button','ComboBox','DirectUIHWND','Tauri Window') and r.get('title'):
        out.append(f"{c} {r.get('id')} {r['title']}")
open(sys.argv[2],'w',encoding='utf-8').write('\n'.join(out)+'\n')
