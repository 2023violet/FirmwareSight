param([string]$Exe, [string]$Out, [string]$Fixtures)
# R5 native smoke: QA-identifier build only, empty QA store, Owner store hashed read-only.
# The QA store this run creates is KEPT under a unique name and listed, never deleted.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.r5-aside-" + (Get-Date -Format "HHmmss")
if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $aside }
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Click($name) { node cdp.mjs click $name | Out-Null }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
function JClick($expr) { J "(() => { const el = $expr; if (!el) return 'MISSING'; el.click(); return 'ok' })()" }
function Region($name) { "[...document.querySelectorAll('[aria-label]')].find(n => n.getAttribute('aria-label') === '$name')" }
function ButtonStarting($prefix) { "[...document.querySelectorAll('button')].find(b => b.textContent.startsWith('$prefix'))" }
function Key($key, $ctrl) { J "document.dispatchEvent(new KeyboardEvent('keydown', { key: '$key', ctrlKey: $ctrl, bubbles: true }))" | Out-Null }
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null

  foreach ($side in 'base', 'target') {
    Click '选择固件镜像文件'
    & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\firmware.elf" | Out-Null
    Start-Sleep 1
    Click '添加 MAP'
    & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\firmware.map" | Out-Null
    Start-Sleep 1
    Click '分析'
    Start-Sleep 3
  }

  $rail = J "[...document.querySelectorAll('nav button')].map(b => b.textContent.trim()).join('|')"
  Rec 'H01' (V ($rail -match '发布\|历史' -and $rail -notmatch '发布门禁')) "navigation names: $rail"

  Click '历史 页面'
  Start-Sleep 2
  $none = J "($(Region '固定基线'))?.textContent"
  $tabs = J "[...document.querySelectorAll('[role=tab]')].map(t => t.textContent).join('|')"
  node cdp.mjs shot "$Out\01-history-no-pin.png" | Out-Null
  Rec 'H02' (V ($none -match '尚未固定基线' -and $tabs -match '构建\|Gate 运行\|发布记录')) "History: pin line '$none' | tabs $tabs"

  $pinBtn = J "[...document.querySelectorAll('button[aria-label]')].map(b => b.getAttribute('aria-label')).find(x => x.includes('85ae4fc4e2b8') && x.endsWith('固定为基线'))"
  JClick "[...document.querySelectorAll('button[aria-label]')].find(b => b.getAttribute('aria-label') === $pinBtn)" | Out-Null
  Start-Sleep 2
  $pinned = J "($(Region '固定基线'))?.textContent"
  $chip = J "[...document.querySelectorAll('tbody tr')].map(r => r.textContent).find(x => x.includes('固定基线'))"
  node cdp.mjs shot "$Out\02-history-pinned.png" | Out-Null
  Rec 'H03' (V ($pinned -match '85ae4fc4e2b8' -and $pinned -match '固定于' -and $chip -ne '' -and $chip -ne 'null')) "pin the base build: $pinned"

  $row = J "[...document.querySelectorAll('button[aria-label]')].map(b => b.getAttribute('aria-label')).find(n => n.startsWith('查看 ') && n.endsWith('的存储记录'))"
  Click ($row.Trim('"'))
  Start-Sleep 1
  $insp = J "(() => { const a = document.querySelector('aside[aria-labelledby=fs-inspector-title]'); return a ? a.getAttribute('role') + ' | ' + a.textContent : null })()"
  node cdp.mjs shot "$Out\03-history-row-inspector.png" | Out-Null
  Rec 'H04' (V ($insp -match 'complementary' -and $insp -match 'FirmwareSight 存储')) "a stored row opens the Inspector, first action in the row: $insp"
  Click '关闭证据面板'

  JClick "$(ButtonStarting '与当前构建对比')" | Out-Null
  Start-Sleep 4
  $h1 = J "document.querySelector('h1')?.textContent"
  $bar = J "($(Region '本页主体'))?.textContent"
  $lead = J "[...document.querySelectorAll('section[aria-labelledby]')].map(s => s.textContent).find(x => x.startsWith('Flash 变化'))"
  node cdp.mjs shot "$Out\04-compare-from-history.png" | Out-Null
  Rec 'H05' (V ($h1 -match '对比' -and $bar -match '85ae4fc4e2b8' -and $bar -match '固定基线' -and $bar -match '3c9daa4f7c09' -and $lead -match '▲')) "compare the pinned baseline with the current build, run once: $bar | $lead"

  Key 'k' 'true'
  Start-Sleep 1
  $pal = J "(() => { const d = [...document.querySelectorAll('[role=dialog]')].find(x => x.getAttribute('aria-label') === '命令面板'); return d ? d.querySelectorAll('[role=option]').length + ' options; focus=' + document.activeElement?.getAttribute('role') : null })()"
  node cdp.mjs shot "$Out\05-command-palette.png" | Out-Null
  JClick "[...document.querySelectorAll('[role=option]')].find(o => o.textContent.includes('设置'))" | Out-Null
  Start-Sleep 1
  $h1b = J "document.querySelector('h1')?.textContent"
  Rec 'H06' (V ($pal -match '[1-9]\d* options; focus=combobox' -and $h1b -match '设置')) "Ctrl+K palette: $pal; ran Go to Settings -> $h1b"

  Click '重置应用设置'
  Start-Sleep 1
  $reset = J "(() => { const d = document.querySelector('[role=dialog][aria-modal=true]'); return d ? d.textContent.slice(0, 80) + ' | focus=' + document.activeElement?.textContent : null })()"
  node cdp.mjs shot "$Out\06-settings-reset-sheet.png" | Out-Null
  J "document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))" | Out-Null
  Start-Sleep 1
  $after = J "document.querySelectorAll('[role=dialog]').length"
  Rec 'H07' (V ($reset -ne 'null' -and $reset -match 'focus=' -and $after -eq '0')) "Settings reset asks in a Sheet, Esc keeps the preferences: $reset; dialogs after Esc $after"

  Click '帮助 页面'
  Start-Sleep 1
  $help = J "($(Region '键盘快捷键'))?.textContent"
  Rec 'H08' (V ($help -match 'Ctrl\+K' -and $help -match 'Ctrl\+O')) "Help lists the shortcuts: $help"

  Click '历史 页面'
  Start-Sleep 2
  Key ']' 'false'
  Start-Sleep 1
  $tab = J "document.querySelector('[role=tab][aria-selected=true]')?.textContent"
  Key '/' 'false'
  $focus = J "document.activeElement?.getAttribute('type')"
  Rec 'H09' (V ($tab -match 'Gate 运行' -and $focus -match 'search')) "] moves to the next view ($tab); / focuses the filter ($focus)"

  Click '取消固定'
  Start-Sleep 1
  $unpinned = J "($(Region '固定基线'))?.textContent"
  Rec 'H10' (V ($unpinned -match '尚未固定基线')) "unpin: $unpinned"

  $dark = (node cdp.mjs darkshot "$Out\07-history-dark.png" | Out-String).Trim() -replace '\s+', ' ' -replace ' saved \S+', ''
  Rec 'H11' (V ($dark -match '"theme":"dark"')) "dark theme on History: $dark"

  Click '设置 页面'
  Start-Sleep 1
  $en = JClick "[...document.querySelectorAll('input[type=radio]')].find(i => document.querySelector('label[for=' + JSON.stringify(i.id) + ']')?.textContent.trim() === 'English')"
  Start-Sleep 2
  Click 'History page'
  Start-Sleep 2
  $enTabs = J "[...document.querySelectorAll('[role=tab]')].map(t => t.textContent).join('|')"
  $enRail = J "[...document.querySelectorAll('nav button')].map(b => b.textContent.trim()).join('|')"
  node cdp.mjs shot "$Out\08-history-english.png" | Out-Null
  Rec 'H12' (V ($en -match 'ok' -and $enTabs -match 'Builds\|Gate runs\|Release records' -and $enRail -match 'Release\|History')) "English: tabs $enTabs | rail $enRail"

  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.r5-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  if (Test-Path "$a\$aside") { Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa" }
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec 'H13' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
Rec 'H14' 'NOT_RUN' 'window minimum 1024x720 drag clamp (carried from R1 A10; needs a human drag)'
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
