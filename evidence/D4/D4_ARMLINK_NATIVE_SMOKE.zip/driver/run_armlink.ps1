param([string]$Exe, [string]$Out, [string]$Fixtures)
# ADR-0036 native smoke: a Keil / Arm Compiler build (AXF + armlink MAP) through the desktop's real dialogs.
# QA-identifier build only; the QA store is KEPT; the Owner store is only hashed.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.arm-aside-" + (Get-Date -Format "HHmmss")
if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $aside }
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Click($name) { node cdp.mjs click $name | Out-Null }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null
  foreach ($side in 'base', 'target') {
    Click '选择固件镜像文件'
    & .\dialog.ps1 -ProcId $p.Id -Title '选择要分析的固件文件' -FilePath "$Fixtures\$side\firmware.axf" | Out-Null
    Start-Sleep 1
    Click '添加 MAP'
    & .\dialog.ps1 -ProcId $p.Id -Title '链接器 MAP' -FilePath "$Fixtures\$side\firmware.map" | Out-Null
    Start-Sleep 1
    Click '分析'
    Start-Sleep 4
  }
  $lead = J "[...document.querySelectorAll('section[aria-labelledby]')].map(s => s.textContent).find(x => x.startsWith('Flash 已用')) ?? document.querySelector('main')?.textContent.slice(0, 200)"
  $bar = J "[...document.querySelectorAll('[role=region]')].find(n => n.getAttribute('aria-label') === '本页主体')?.textContent"
  $alerts = J "document.querySelectorAll('[role=alert]').length"
  Rec 'A01' (V ($lead -match '192' -and $bar -match 'firmware.map' -and $alerts -eq '0')) "Analyze an armlink build with its MAP: lead $lead | SubjectBar $bar | alerts $alerts"
  $regions = J "document.querySelector('main')?.innerText.match(/ER_IROM1[\s\S]{0,200}/)?.[0] ?? 'NO_REGION'"
  Rec 'A02' (V ($regions -match 'ER_IROM1' -and $regions -match '64 KiB|65,536|65536')) "region usage from the scatter file's execution region: $regions"
  node cdp.mjs shot "$Out\01-armlink-analyze.png" | Out-Null
  Click '对象'
  Start-Sleep 2
  $objects = J "(() => { const t = document.querySelector('[role=tabpanel]'); return t ? t.innerText.slice(0, 600) : null })()"
  Rec 'A03' (V ($objects -match 'libdrv.lib\(spi.o\)' -and $objects -match 'imu.o')) "Objects view attributes the armlink rows: $objects"
  node cdp.mjs shot "$Out\02-armlink-objects.png" | Out-Null
  Click '对比 页面'
  Start-Sleep 2
  Click '对比'
  Start-Sleep 4
  $cmp = J "[...document.querySelectorAll('section[aria-labelledby]')].map(s => s.textContent).find(x => x.startsWith('Flash 变化'))"
  Rec 'A04' (V ($cmp -match '▲84' -and $cmp -match 'imu.o|ER_IROM1')) "Compare two armlink builds with MAPs: $cmp"
  node cdp.mjs shot "$Out\03-armlink-compare.png" | Out-Null
  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.arm-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  if (Test-Path "$a\$aside") { Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa" }
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec 'A05' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
