﻿param([int]$ProcId, [string]$FilePath, [int]$TimeoutSec = 10, [switch]$Cancel, [string]$Title = '')
# Fill and confirm the visible native file dialog (#32770) owned by the QA process only.
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class Dlg {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern IntPtr GetDlgItem(IntPtr h, int id);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr SendMessageTimeoutW(IntPtr h, uint msg, IntPtr w, string l, uint flags, uint timeout, out IntPtr result);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeoutW(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  public delegate bool ChildProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, ChildProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr h);
  // A Save dialog keeps its file-name Edit inside a combo box, several levels below the dialog (id 1001).
  public static IntPtr SaveNameEdit(IntPtr dlg) {
    IntPtr found = IntPtr.Zero;
    EnumChildWindows(dlg, (h, l) => {
      var sb = new StringBuilder(64); GetClassName(h, sb, 64);
      if (sb.ToString() == "Edit" && GetDlgCtrlID(h) == 1001 && IsWindowVisible(h)) { found = h; return false; }
      return true;
    }, IntPtr.Zero);
    return found;
  }
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  public static IntPtr Find(uint want, string title) {
    IntPtr found = IntPtr.Zero;
    EnumWindows((h, l) => {
      uint pid; GetWindowThreadProcessId(h, out pid);
      if (pid != want || !IsWindowVisible(h)) return true;
      var sb = new StringBuilder(64); GetClassName(h, sb, 64);
      var tb = new StringBuilder(256); GetWindowText(h, tb, 256);
      if (sb.ToString() == "#32770" && (title.Length == 0 || tb.ToString().Contains(title))) { found = h; return false; }
      return true;
    }, IntPtr.Zero);
    return found;
  }
}
"@
$deadline = (Get-Date).AddSeconds($TimeoutSec)
$dlg = [IntPtr]::Zero
while ($dlg -eq [IntPtr]::Zero -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 300; $dlg = [Dlg]::Find([uint32]$ProcId, $Title) }
if ($dlg -eq [IntPtr]::Zero) { 'NO_DIALOG'; exit 2 }
$r = [IntPtr]::Zero
if ($Cancel) {
  $cancelButton = [Dlg]::GetDlgItem($dlg, 2)
  [void][Dlg]::SendMessageTimeoutW($cancelButton, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero, 2, 3000, [ref]$r) # BM_CLICK IDCANCEL
  Start-Sleep -Milliseconds 800
  'DIALOG_CANCELLED'
  exit 0
}
$edit = [Dlg]::GetDlgItem($dlg, 1148)
if ($edit -eq [IntPtr]::Zero) { $edit = [Dlg]::SaveNameEdit($dlg) }
if ($edit -eq [IntPtr]::Zero) { 'NO_EDIT'; exit 3 }
$r = [IntPtr]::Zero
[void][Dlg]::SendMessageTimeoutW($edit, 0x000C, [IntPtr]::Zero, $FilePath, 2, 3000, [ref]$r)   # WM_SETTEXT
$ok = [Dlg]::GetDlgItem($dlg, 1)
[void][Dlg]::SendMessageTimeoutW($ok, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero, 2, 3000, [ref]$r) # BM_CLICK
Start-Sleep -Milliseconds 800
'DIALOG_OK'
