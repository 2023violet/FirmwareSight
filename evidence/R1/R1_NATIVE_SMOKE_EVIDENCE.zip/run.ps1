param([string]$Exe, [string]$Out)
# R1 native smoke: QA-identifier build only, empty QA store, Owner store hashed read-only.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
Rename-Item "$a\com.firmwaresight.desktop.qa" "com.firmwaresight.desktop.qa.r1-aside"
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() }
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  $state = "({w: innerWidth, pressed: document.querySelector('[aria-controls=fs-rail]').getAttribute('aria-pressed'), rail: getComputedStyle(document.getElementById('fs-rail')).width})"
  $s = J $state; Rec 'A01' ($(if ($s -match '"pressed": "true"' -and $s -match '"rail": "224px"') { 'PASS' } else { 'FAIL' })) "default window: $($s -replace '\s+',' ')"
  node cdp.mjs shot "$Out\01-default-light.png" | Out-Null
  $pages = '总览 页面','对比 页面','发布门禁 页面','发布包与历史 页面','帮助 页面','设置 页面','分析 页面'
  $ok = $true; $seen = @()
  foreach ($n in $pages) {
    node cdp.mjs click $n | Out-Null
    $r = J "document.querySelector('[aria-current=page]')?.getAttribute('aria-label') + '|' + document.querySelector('h1')?.textContent"
    $seen += $r
    if ($r -notmatch [regex]::Escape($n)) { $ok = $false }
  }
  Rec 'A02' ($(if ($ok) { 'PASS' } else { 'FAIL' })) ("rail navigation: " + ($seen -join ' ; '))
  & .\resize.ps1 -ProcId $p.Id -W 1100 -H 760 | Out-Null
  $s = J $state; Rec 'A03' ($(if ($s -match '"pressed": "false"' -and $s -match '"rail": "56px"') { 'PASS' } else { 'FAIL' })) "window narrower than 1180: $($s -replace '\s+',' ')"
  node cdp.mjs shot "$Out\02-collapsed-1100.png" | Out-Null
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null
  $s = J $state; Rec 'A04' ($(if ($s -match '"pressed": "true"') { 'PASS' } else { 'FAIL' })) "back above 1180: $($s -replace '\s+',' ')"
  node cdp.mjs click '页面名称' | Out-Null
  $s = J $state; Rec 'A05' ($(if ($s -match '"pressed": "false"' -and $s -match '"rail": "56px"') { 'PASS' } else { 'FAIL' })) "reader toggle at 1440: $($s -replace '\s+',' ')"
  node cdp.mjs click '页面名称' | Out-Null
  node cdp.mjs click '帮助 页面' | Out-Null
  $g = J "['pass','review','block','unknown','na'].map(n => n + ':' + document.querySelectorAll('svg[data-icon=' + n + ']').length).join(' ')"
  Rec 'A06' ($(if ($g -notmatch ':0') { 'PASS' } else { 'FAIL' })) "Help state glyphs present: $g"
  node cdp.mjs shot "$Out\03-help-states-light.png" | Out-Null
  $t = J "getComputedStyle(document.querySelector('h1')).fontWeight + ' ' + getComputedStyle(document.documentElement).getPropertyValue('--fs-color-diff-removed') + ' ' + getComputedStyle(document.documentElement).getPropertyValue('--fs-font-size-figure')"
  Rec 'A07' ($(if ($t -match '600' -and $t -match '#C7372C' -and $t -match '28px') { 'PASS' } else { 'FAIL' })) "tokens 0.4.0 live: $t"
  $d = (node cdp.mjs darkshot "$Out\04-help-dark.png" | Out-String).Trim()
  Rec 'A08' ($(if ($d -match '"theme":"dark"' -and $d -match '#F2705F') { 'PASS' } else { 'FAIL' })) "dark theme via system preference: $($d -replace '\s+',' ')"
  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" "com.firmwaresight.desktop.qa.r1-final-kept" }
  Rename-Item "$a\com.firmwaresight.desktop.qa.r1-aside" "com.firmwaresight.desktop.qa"
}
$after = OwnerHashes
Rec 'A09' ($(if (-not (Compare-Object $before $after)) { 'PASS' } else { 'FAIL' })) "Owner app data unchanged: $($after.Count) files, identical hashes"
Rec 'A10' 'NOT_RUN' 'window minimum 1024x720 clamp: programmatic MoveWindow bypasses the minimum; needs one human drag-resize'
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
