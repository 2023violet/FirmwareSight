param([string]$Exe, [string]$Out)
# OS-level input on the QA build: a real mouse drag of the window's sizing corner, and real key presses.
# CDP is used only to read the page; every action below goes through the Windows input queue.
# The QA store is KEPT and listed, never deleted; the Owner's store is only hashed.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class Os {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr v);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, int x, int y, uint d, UIntPtr e);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint f, UIntPtr e);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, System.Text.StringBuilder s, int n);
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  public static IntPtr Dialog(uint want) {
    IntPtr found = IntPtr.Zero;
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid);
      if (pid != want || !IsWindowVisible(h)) return true;
      var sb = new System.Text.StringBuilder(64); GetClassName(h, sb, 64);
      if (sb.ToString() == "#32770") { found = h; return false; } return true; }, IntPtr.Zero);
    return found;
  }
  public static void Key(byte vk, bool up) { keybd_event(vk, 0, up ? 2u : 0u, UIntPtr.Zero); }
  public static void Tap(byte vk) { Key(vk, false); System.Threading.Thread.Sleep(40); Key(vk, true); System.Threading.Thread.Sleep(120); }
  public static void Chord(byte mod, byte vk) { Key(mod, false); Tap(vk); Key(mod, true); System.Threading.Thread.Sleep(200); }
}
"@
[void][Os]::SetProcessDpiAwarenessContext([IntPtr](-4))   # per-monitor v2: physical pixels throughout
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.os-aside-" + (Get-Date -Format "HHmmss")
if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $aside }
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Logical($h) {
  $c = New-Object Os+RECT; [void][Os]::GetClientRect($h, [ref]$c); $s = [Os]::GetDpiForWindow($h) / 96.0
  return @([math]::Round($c.R / $s), [math]::Round($c.B / $s), $s)
}
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  $p.Refresh(); $h = $p.MainWindowHandle
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null
  Start-Sleep 1

  # O01: drag the bottom-right sizing corner far up and left with the real mouse.
  [void][Os]::SetForegroundWindow($h); Start-Sleep -Milliseconds 400
  $r = New-Object Os+RECT; [void][Os]::GetWindowRect($h, [ref]$r)
  $start = Logical $h
  $x = $r.R - 4; $y = $r.B - 4
  $hit = [int][Os]::SendMessageW($h, 0x84, [IntPtr]::Zero, [IntPtr](($y -shl 16) -bor ($x -band 0xFFFF)))   # WM_NCHITTEST
  [void][Os]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 200
  [Os]::mouse_event(0x2, 0, 0, 0, [UIntPtr]::Zero)                   # left down
  for ($i = 1; $i -le 20; $i++) { [void][Os]::SetCursorPos($x - 50 * $i, $y - 40 * $i); Start-Sleep -Milliseconds 40 }
  [Os]::mouse_event(0x4, 0, 0, 0, [UIntPtr]::Zero)                   # left up
  Start-Sleep 1
  $end = Logical $h
  Rec 'O01' (V ($hit -eq 17 -and $end[0] -ge 1024 -and $end[1] -ge 720 -and $end[0] -lt $start[0])) "real mouse drag of the sizing corner (hit-test $hit = HTBOTTOMRIGHT 17) 1000x800 px up-left: client $($start[0])x$($start[1]) -> $($end[0])x$($end[1]) logical px at scale $($end[2]); minimum 1024x720 held"
  node cdp.mjs shot "$Out\01-after-drag.png" | Out-Null
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null
  Start-Sleep 1

  # Keyboard-only: every step below is a key press in the Windows input queue.
  [void][Os]::SetForegroundWindow($h); Start-Sleep -Milliseconds 400
  J "document.activeElement && document.activeElement.blur(); document.body.focus(); 'ok'" | Out-Null
  [Os]::Tap(0x09)   # Tab
  $first = J "({ tag: document.activeElement?.tagName, text: document.activeElement?.textContent?.trim(), href: document.activeElement?.getAttribute('href') })"
  Rec 'O02' (V ($first -match '"tag": "A"' -and $first -match '#')) "first Tab lands on the skip link: $first"
  [Os]::Tap(0x0D)   # Enter
  Start-Sleep -Milliseconds 300
  $main = J "({ id: document.activeElement?.id, tag: document.activeElement?.tagName })"
  Rec 'O03' (V ($main -notmatch '"tag": "A"' -and $main -notmatch '"tag": "BODY"')) "Enter on the skip link moves focus into the workspace: $main"

  [Os]::Chord(0x11, 0x4B)   # Ctrl+K
  Start-Sleep -Milliseconds 500
  $pal = J "({ dialog: !!document.querySelector('[role=dialog] [role=combobox]'), focus: document.activeElement?.getAttribute('role') })"
  [Os]::Tap(0x28); [Os]::Tap(0x28)   # Down, Down
  $active = J "document.activeElement?.getAttribute('aria-activedescendant')"
  [Os]::Tap(0x1B)   # Esc
  Start-Sleep -Milliseconds 400
  $closed = J "({ dialog: !!document.querySelector('[role=dialog] [role=combobox]') })"
  Rec 'O04' (V ($pal -match '"dialog": true' -and $pal -match 'combobox' -and $active -ne 'null' -and $active -ne '' -and $closed -match 'false')) "Ctrl+K opens the palette with focus in its combobox ($pal); Down moves the active option ($active); Esc closes it ($closed)"

  [Os]::Chord(0x11, 0x4F)   # Ctrl+O
  Start-Sleep 2
  $dlg = [Os]::Dialog([uint32]$p.Id)
  $opened = $dlg -ne [IntPtr]::Zero
  if ($opened) { [void][Os]::SetForegroundWindow($dlg); Start-Sleep -Milliseconds 300; [Os]::Tap(0x1B); Start-Sleep 1 }
  $after = [Os]::Dialog([uint32]$p.Id)
  $alerts = J "document.querySelectorAll('[role=alert]').length"
  Rec 'O05' (V ($opened -and $after -eq [IntPtr]::Zero -and $alerts -eq '0')) "Ctrl+O opens the native file dialog (opened $opened); Esc cancels it (still open: $($after -ne [IntPtr]::Zero)); alerts $alerts"

  [void][Os]::SetForegroundWindow($h); Start-Sleep -Milliseconds 400
  [Os]::Chord(0x11, 0x4B); Start-Sleep -Milliseconds 400
  $target = J "[...document.querySelectorAll('[role=option]')].findIndex(o => o.textContent.includes('设置'))"
  for ($i = 0; $i -lt [int]$target; $i++) { [Os]::Tap(0x28) }
  [Os]::Tap(0x0D); Start-Sleep 1
  $h1 = J "({ h1: document.querySelector('h1')?.textContent, focus: document.activeElement?.tagName })"
  Rec 'O06' (V ($h1 -match '设置' -and $h1 -match 'H1')) "palette by keyboard only: Down x$target, Enter -> page and focus: $h1"
  node cdp.mjs shot "$Out\02-settings-by-keyboard.png" | Out-Null

  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.os-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  if (Test-Path "$a\$aside") { Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa" }
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec 'O07' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
