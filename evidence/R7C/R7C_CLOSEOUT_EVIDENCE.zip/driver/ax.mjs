// The accessibility tree Chromium hands to UI Automation (and so to NVDA and Narrator), summarized.
// Usage: node ax.mjs  -> JSON { interactive, unnamed[], tables, captioned, headings, landmarks{}, live }
const list = await (await fetch('http://127.0.0.1:9333/json/list')).json();
const page = list.find((t) => t.type === 'page' && t.url.startsWith('http://tauri.localhost'));
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener('open', r, { once: true }));
let id = 0;
const pending = new Map();
ws.addEventListener('message', (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } });
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
await send('Accessibility.enable');
const { result } = await send('Accessibility.getFullAXTree');
const nodes = result.nodes.filter((n) => !n.ignored);
const role = (n) => n.role?.value ?? '';
const name = (n) => (n.name?.value ?? '').trim();
const INTERACTIVE = new Set(['button', 'link', 'textbox', 'searchbox', 'combobox', 'tab', 'radio', 'checkbox', 'menuitem', 'option', 'switch', 'slider']);
const LANDMARK = new Set(['main', 'navigation', 'banner', 'complementary', 'contentinfo', 'region', 'search', 'form']);
const interactive = nodes.filter((n) => INTERACTIVE.has(role(n)));
const unnamed = interactive.filter((n) => !name(n)).map((n) => role(n));
const tables = nodes.filter((n) => role(n) === 'table');
const landmarks = {};
for (const n of nodes) if (LANDMARK.has(role(n))) landmarks[role(n)] = (landmarks[role(n)] ?? 0) + 1;
const live = nodes.filter((n) => (n.properties ?? []).some((p) => p.name === 'live' && p.value?.value !== 'off')).length;
console.log(JSON.stringify({
  interactive: interactive.length,
  unnamed,
  tables: tables.length,
  captioned: tables.filter((n) => name(n)).length,
  headings: nodes.filter((n) => role(n) === 'heading').length,
  landmarks,
  live,
}));
ws.close();
