﻿param([string]$Exe, [string]$Out, [string]$Fixture)
# Content scaling at 125% and 150% (WebView2 device scale factor; the system DPI setting is not changed),
# at the 1024x720 minimum, plus a UI Automation audit of what a screen reader is given.
# The QA store is KEPT and listed; the Owner's store is only hashed.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.scale-aside-" + (Get-Date -Format "HHmmss")
if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $aside }
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Click($name) { node cdp.mjs click $name | Out-Null }
$overflow = "(() => { const ws = [...document.querySelectorAll('main, main *')].filter(el => { const s = getComputedStyle(el); return s.overflowX === 'visible' && el.scrollWidth > el.clientWidth + 1 && el.clientWidth > 0 && !el.closest('[role=group][aria-label], table, pre'); }).slice(0, 3).map(el => el.tagName + '.' + String(el.className).split(' ')[0] + ':' + el.scrollWidth + '>' + el.clientWidth); return { dpr: devicePixelRatio, w: innerWidth, h: innerHeight, page: document.documentElement.scrollWidth > document.documentElement.clientWidth, ws }; })()"
try {
  $n = 0
  foreach ($scale in '1.25', '1.5') {
    $n++
    $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = "--remote-debugging-port=9333 --force-device-scale-factor=$scale"
    $p = Start-Process $Exe -PassThru
    Start-Sleep 7
    & .\resize.ps1 -ProcId $p.Id -W 1024 -H 720 | Out-Null
    Start-Sleep 1
    if ($n -eq 1) {
      Click '选择固件镜像文件'; & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixture\firmware.elf" | Out-Null; Start-Sleep 1
      Click '添加 MAP'; & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixture\firmware.map" | Out-Null; Start-Sleep 1
      Click '分析'; Start-Sleep 3
    }
    $rows = @()
    foreach ($page in '总览', '分析', '对比', '发布', '历史', '帮助', '设置') {
      Click "$page 页面"; Start-Sleep 2
      $r = J $overflow
      $rows += "$page $r"
      node cdp.mjs shot "$Out\$scale-$page.png" | Out-Null
    }
    $bad = $rows | Where-Object { $_ -match '"page": true' -or $_ -notmatch '"ws": \[\]' }
    Rec "S0$n" (V ($rows.Count -eq 7 -and -not $bad -and $rows[0] -match ('"dpr": ' + $scale))) "content scale $scale at 1024x720: 7 pages, no page-level horizontal scroll and no clipped block outside a scroll region; $(($rows | ForEach-Object { ($_ -split ' ')[0] + ' ' + (($_ -replace '.*"w": (\d+), "h": (\d+).*', '$1x$2')) }) -join '; ') CSS px$(if ($bad) { ' | ' + ($bad -join ' | ') })"

    if ($n -eq 2) {
      # What a screen reader is handed: Chromium's accessibility tree, which WebView2 exposes to UI Automation.
      $ax = @()
      foreach ($page in '分析', '对比', '发布', '历史') {
        Click "$page 页面"; Start-Sleep 2
        if ($page -eq '对比') { Click '对比'; Start-Sleep 3 }
        $ax += "$page " + (node ax.mjs | Out-String).Trim()
      }
      $bad = $ax | Where-Object { $_ -notmatch '"unnamed":\[\]' -or $_ -notmatch '"main":1' -or $_ -notmatch '"navigation"' }
      $tablesOk = -not ($ax | Where-Object { ($_ -replace '.*"tables":(\d+),"captioned":(\d+).*', '$1') -ne ($_ -replace '.*"tables":(\d+),"captioned":(\d+).*', '$2') })
      Rec 'S03' (V (-not $bad -and $tablesOk)) "accessibility tree (what UI Automation hands NVDA/Narrator) on four workspaces: every interactive element named, one main landmark, navigation present, every table named by its caption | $($ax -join ' | ')"
    }
    Stop-Process -Id $p.Id
    Start-Sleep 3
  }
}
finally {
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.scale-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  if (Test-Path "$a\$aside") { Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa" }
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec 'S04' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
