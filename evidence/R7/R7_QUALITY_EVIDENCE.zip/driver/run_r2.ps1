param([string]$Exe, [string]$Out, [string]$Fixture)
# R2 native smoke: QA-identifier build only, empty QA store, Owner store hashed read-only.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
Rename-Item "$a\com.firmwaresight.desktop.qa" "com.firmwaresight.desktop.qa.r2-aside"
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Click($name) { node cdp.mjs click $name | Out-Null }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null

  Click '选择固件镜像文件'
  $d1 = & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixture\firmware.elf"
  Start-Sleep 1
  $bar = J "document.querySelector('[aria-label=本页主体]')?.textContent"
  Rec 'B01' (V ($d1 -eq 'DIALOG_OK' -and $bar -match 'firmware\.elf' -and $bar -match '尚未分析')) "choose ELF through the native dialog; SubjectBar: $bar"

  Click '添加 MAP'
  $d2 = & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixture\firmware.map"
  Start-Sleep 1
  $bar = J "document.querySelector('[aria-label=本页主体]')?.textContent"
  Rec 'B02' (V ($d2 -eq 'DIALOG_OK' -and $bar -match 'MAP：firmware\.map')) "attach MAP; SubjectBar: $bar"

  Click '分析'
  Start-Sleep 3
  $lead = J "[...document.querySelectorAll('section')].find(s => s.getAttribute('aria-labelledby') && document.getElementById(s.getAttribute('aria-labelledby'))?.textContent === 'Flash 已用')?.textContent"
  $bar = J "document.querySelector('[aria-label=本页主体]')?.textContent"
  Rec 'B03' (V ($lead -match '196 bytes' -and $lead -match 'RAM 44 bytes' -and $bar -match '3c9daa4f7c09' -and $bar -match '最新')) "analyze; lead: $lead | SubjectBar: $bar"
  node cdp.mjs shot "$Out\01-analyze-memory-1440.png" | Out-Null

  $figure = J "document.querySelector('section[aria-labelledby] button[aria-label^=\'196 bytes\']')?.getAttribute('aria-label')"
  Click ($figure.Trim('"'))
  Start-Sleep 1
  $insp = J "(() => { const a = document.querySelector('aside[aria-labelledby=fs-inspector-title]'); return a ? a.getAttribute('role') + ' | ' + a.textContent : null })()"
  node cdp.mjs shot "$Out\02-inspector-docked.png" | Out-Null
  $focus = J "document.activeElement?.getAttribute('aria-label')"
  Rec 'B04' (V ($insp -match 'complementary' -and $insp -match 'nonvolatile_image_footprint_bytes' -and $focus -match '关闭证据面板')) "lead figure opens the docked Inspector; focus on close; $insp"

  & .\resize.ps1 -ProcId $p.Id -W 1100 -H 760 | Out-Null
  Start-Sleep 1
  $sheet = J "(() => { const a = document.querySelector('aside[aria-labelledby=fs-inspector-title]'); return a ? a.getAttribute('role') + ' modal=' + a.getAttribute('aria-modal') : null })()"
  node cdp.mjs shot "$Out\03-inspector-sheet-1100.png" | Out-Null
  Rec 'B05' (V ($sheet -match 'dialog modal=true')) "below 1280 the open Inspector becomes a modal sheet without closing: $sheet"
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null
  Click '关闭证据面板'

  $views = @()
  foreach ($v in '节', '符号', '对象', '证据') {
    Click $v
    Start-Sleep 1
    $views += "$v=" + (J "(() => { const t = document.querySelector('[role=tabpanel]'); return t ? (t.getAttribute('aria-labelledby') + ':' + t.querySelectorAll('tbody tr').length + 'rows' + (t.textContent.includes('sensors/imu.o') ? ':imu' : '')) : null })()")
  }
  $vs = $views -join ' ; '
  Rec 'B06' (V ($vs -match '节=.*[1-9]\d*rows' -and $vs -match '对象=.*:imu' -and $vs -notmatch ':0rows')) "views render their tables: $vs"
  node cdp.mjs shot "$Out\04-evidence-view.png" | Out-Null

  $row = J "document.querySelector('[role=tabpanel] button[aria-label^=\'查看 \']')?.getAttribute('aria-label')"
  Click ($row.Trim('"'))
  Start-Sleep 1
  $insp = J "document.querySelector('aside[aria-labelledby=fs-inspector-title]')?.textContent"
  Rec 'B07' (V ($insp -match 'Observed|Derived|Declared|Unknown')) "an evidence row opens the shared Inspector ($row): $insp"
  Click '关闭证据面板'

  Click '总览 页面'
  Start-Sleep 1
  $order = J "(() => { const bar = [...document.querySelectorAll('[role=region]')].find(n => n.getAttribute('aria-label') === '本页主体'); const ship = [...document.querySelectorAll('section')].find(n => n.getAttribute('aria-label') === '现在可以发布吗？'); const prim = [...document.querySelectorAll('main button')].filter(b => /primary/.test(b.className)).map(b => b.textContent); return { bar: bar?.textContent, shipAfterBar: !!(bar && ship && (bar.compareDocumentPosition(ship) & 4)), primaries: prim } })()"
  node cdp.mjs shot "$Out\05-overview.png" | Out-Null
  Rec 'B08' (V ($order -match '3c9daa4f7c09' -and $order -match '"shipAfterBar": true' -and $order -match '"primaries": \[ "[^"]+" \]')) "Overview: subject, then the ship answer, one primary action: $order"

  Click '分析 页面'
  Start-Sleep 1
  $dark = (node cdp.mjs darkshot "$Out\06-analyze-dark.png" | Out-String).Trim() -replace '\s+', ' ' -replace ' saved \S+', ''
  Rec 'B09' (V ($dark -match '"theme":"dark"')) "dark theme on the redesigned Analyze page: $dark"

  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" ("com.firmwaresight.desktop.qa.r2-kept-" + (Get-Date -Format "HHmmss")) }
  Rename-Item "$a\com.firmwaresight.desktop.qa.r2-aside" "com.firmwaresight.desktop.qa"
}
$after = OwnerHashes
Rec 'B10' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
