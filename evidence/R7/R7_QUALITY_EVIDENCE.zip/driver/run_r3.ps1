param([string]$Exe, [string]$Out, [string]$Fixtures)
# R3 native smoke: QA-identifier build only, empty QA store, Owner store hashed read-only.
# The QA store this run creates is KEPT under a unique name and listed, never deleted.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.r3-aside-" + (Get-Date -Format "HHmmss")
Rename-Item "$a\com.firmwaresight.desktop.qa" $aside
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Click($name) { node cdp.mjs click $name | Out-Null }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
function JClick($expr) { J "(() => { const el = $expr; if (!el) return 'MISSING'; el.click(); return 'ok' })()" }
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null

  foreach ($side in 'base', 'target') {
    Click '选择固件镜像文件'
    & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\firmware.elf" | Out-Null
    Start-Sleep 1
    Click '添加 MAP'
    & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\firmware.map" | Out-Null
    Start-Sleep 1
    Click '分析'
    Start-Sleep 3
  }

  Click '对比 页面'
  Start-Sleep 2
  Click '对比'
  Start-Sleep 3
  $lead = J "[...document.querySelectorAll('section[aria-labelledby]')].map(s => s.textContent).find(x => x.startsWith('Flash 变化'))"
  $bar = J "[...document.querySelectorAll('[role=region]')].find(n => n.getAttribute('aria-label') === '本页主体')?.textContent"
  Rec 'C01' (V ($lead -match '▲' -and $lead -match '64' -and $lead -match 'sensors/imu.o' -and $bar -match '85ae4fc4e2b8' -and $bar -match '3c9daa4f7c09' -and $bar -match '最新')) "compare the stored pair; lead: $lead | SubjectBar: $bar"
  node cdp.mjs shot "$Out\01-compare-summary-1440.png" | Out-Null

  $views = @()
  foreach ($v in '节', '符号', '对象') {
    Click $v
    Start-Sleep 1
    $views += "$v=" + (J "(() => { const t = document.querySelector('[role=tabpanel]'); return t ? t.querySelectorAll('tbody tr').length + 'rows' + (t.textContent.includes('sensors/imu.o') ? ':imu' : '') : null })()")
  }
  $vs = $views -join ' ; '
  Rec 'C02' (V ($vs -match '节=.*[1-9]\d*rows' -and $vs -match '符号=.*[1-9]\d*rows' -and $vs -match '对象=.*:imu')) "views render their change tables: $vs"
  node cdp.mjs shot "$Out\02-compare-objects.png" | Out-Null

  Click '概要'
  Start-Sleep 1
  $pick = J "[...document.querySelectorAll('button[aria-label]')].map(b => b.getAttribute('aria-label')).find(n => n.startsWith('显示 ') && n.endsWith('的节变化'))"
  Click ($pick.Trim('"'))
  Start-Sleep 2
  $picked = J "({ tab: document.querySelector('[role=tab][aria-selected=true]')?.textContent, filter: document.querySelector('input[type=search]')?.value })"
  Rec 'C03' (V ($picked -match '"tab": "节"' -and $picked -notmatch '"filter": ""')) "a ranking pick ($pick) opens the Sections view, filtered: $picked"

  $row = J "[...document.querySelectorAll('button[aria-label]')].map(b => b.getAttribute('aria-label')).find(n => n.startsWith('查看 ') && n.endsWith('的变化详情'))"
  Click ($row.Trim('"'))
  Start-Sleep 1
  $insp = J "(() => { const a = document.querySelector('aside[aria-labelledby=fs-inspector-title]'); return a ? a.getAttribute('role') + ' | ' + a.textContent : null })()"
  node cdp.mjs shot "$Out\03-change-row-inspector.png" | Out-Null
  Rec 'C04' (V ($insp -match 'complementary' -and $insp -match '→')) "a change row opens the docked Inspector ($row): $insp"
  & .\resize.ps1 -ProcId $p.Id -W 1100 -H 760 | Out-Null
  Start-Sleep 1
  $sheet = J "(() => { const a = document.querySelector('aside[aria-labelledby=fs-inspector-title]'); return a ? a.getAttribute('role') + ' modal=' + a.getAttribute('aria-modal') : null })()"
  node cdp.mjs shot "$Out\04-inspector-sheet-1100.png" | Out-Null
  Rec 'C05' (V ($sheet -match 'dialog modal=true')) "below 1280 the open Inspector becomes a modal sheet: $sheet"
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null
  Click '关闭证据面板'

  Click '交换'
  Start-Sleep 1
  $bar = J "[...document.querySelectorAll('[role=region]')].find(n => n.getAttribute('aria-label') === '本页主体')?.textContent"
  $lead = J "[...document.querySelectorAll('section[aria-labelledby]')].map(s => s.textContent).find(x => x.startsWith('Flash 变化'))"
  Rec 'C06' (V ($bar -match '已保留上一次对比' -and $lead -match '上一次对比')) "swap marks the comparison on screen as retained: $bar | $lead"
  node cdp.mjs shot "$Out\05-swapped-retained.png" | Out-Null
  Click '交换'
  Start-Sleep 1

  Click '导出'
  Start-Sleep 1
  Click '导出 JSON'
  $d = & .\dialog.ps1 -ProcId $p.Id -FilePath '' -Cancel
  Start-Sleep 1
  $status = J "[...document.querySelectorAll('[role=status]')].map(n => n.textContent).join(' | ')"
  $alerts = J "document.querySelectorAll('[role=alert]').length"
  Rec 'C07' (V ($d -eq 'DIALOG_CANCELLED' -and $status -match '已取消导出' -and $alerts -eq '0')) "export from the menu, cancelled in the native Save dialog: $status (alerts $alerts)"

  Click '分析 页面'
  Start-Sleep 1
  $region = J "[...document.querySelectorAll('button[aria-label]')].map(b => b.getAttribute('aria-label')).find(n => n.includes('FLASH'))"
  Click ($region.Trim('"'))
  Start-Sleep 1
  $rinsp = J "document.querySelector('aside[aria-labelledby=fs-inspector-title]')?.textContent"
  Click '关闭证据面板'
  Click '节'
  Start-Sleep 1
  $secRows = J "document.querySelector('[role=tabpanel]')?.querySelectorAll('tbody tr').length"
  $sortName = J "[...document.querySelectorAll('[role=tabpanel] th button')].map(b => b.textContent).join('|')"
  node cdp.mjs shot "$Out\06-analyze-sections-datatable.png" | Out-Null
  Rec 'C08' (V ($rinsp -match 'LMA' -and [int]$secRows -gt 0)) "Analyze: region evidence in the Inspector ($region), Sections on the shared table ($secRows rows; sortable: $sortName)"

  Click '对比 页面'
  Start-Sleep 1
  $dark = (node cdp.mjs darkshot "$Out\07-compare-dark.png" | Out-String).Trim() -replace '\s+', ' ' -replace ' saved \S+', ''
  Rec 'C09' (V ($dark -match '"theme":"dark"')) "dark theme on Compare: $dark"

  Click '设置 页面'
  Start-Sleep 1
  $en = JClick "[...document.querySelectorAll('input[type=radio]')].find(i => document.querySelector('label[for=' + JSON.stringify(i.id) + ']')?.textContent.trim() === 'English')"
  Start-Sleep 2
  Click 'Compare page'
  Start-Sleep 2
  $enLead = J "[...document.querySelectorAll('section[aria-labelledby]')].map(s => s.textContent).find(x => x.startsWith('Flash change'))"
  $enTabs = J "[...document.querySelectorAll('[role=tab]')].map(t => t.textContent).join('|')"
  node cdp.mjs shot "$Out\08-compare-english.png" | Out-Null
  Rec 'C10' (V ($en -match 'ok' -and $enLead -match '▲' -and $enTabs -match 'Summary\|Sections\|Symbols\|Objects')) "English: lead $enLead | tabs $enTabs"

  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.r3-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa"
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec 'C11' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
Rec 'C12' 'NOT_RUN' 'window minimum 1024x720 drag clamp (carried from R1 A10; needs a human drag)'
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
