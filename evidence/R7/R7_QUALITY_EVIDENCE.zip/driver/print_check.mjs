// A4 print check for one self-contained HTML report, in a headless Edge on CDP port 9444.
// Usage: node print_check.mjs <out.png>
// Emulates print media at the A4 content width and reports what a printed page would get wrong:
// content wider than the page, table headers that do not repeat, rows allowed to split.
import { writeFileSync } from 'node:fs';

const list = await (await fetch('http://127.0.0.1:9444/json/list')).json();
const page = list.find((t) => t.type === 'page' && t.url.startsWith('file:'));
if (!page) throw new Error('no file page target');
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener('open', r, { once: true }));
let id = 0;
const pending = new Map();
ws.addEventListener('message', (e) => {
  const m = JSON.parse(e.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
});
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });

// A4 is 210 mm; at 96 dpi that is 794 px. The reports set their own @page margins, so the check
// uses the full sheet width as the upper bound and reports the widest element against it.
await send('Emulation.setEmulatedMedia', { media: 'print' });
await send('Emulation.setDeviceMetricsOverride', { width: 794, height: 1123, deviceScaleFactor: 1, mobile: false });
const r = await send('Runtime.evaluate', {
  returnByValue: true,
  expression: `(() => {
    const docWidth = document.documentElement.scrollWidth;
    const heads = [...document.querySelectorAll('thead')];
    const repeating = heads.filter(h => getComputedStyle(h).display === 'table-header-group').length;
    const rows = [...document.querySelectorAll('tbody tr')];
    const unsplit = rows.filter(tr => ['avoid', 'avoid-page'].includes(getComputedStyle(tr).breakInside)).length;
    const pageRule = [...document.styleSheets].flatMap(s => { try { return [...s.cssRules]; } catch { return []; } })
      .filter(rule => rule.constructor.name === 'CSSPageRule').map(rule => rule.cssText).join(' ');
    const wide = [...document.body.querySelectorAll('*')]
      .filter(el => el.getBoundingClientRect().right > 794 + 1)
      .slice(0, 5).map(el => el.tagName.toLowerCase() + (el.className ? '.' + String(el.className).split(' ')[0] : '') + ':' + Math.round(el.getBoundingClientRect().right));
    return { docWidth, tables: heads.length, repeatingHeads: repeating, rows: rows.length, rowsKeptWhole: unsplit, pageRule, wide,
             captions: document.querySelectorAll('caption').length, scopedTh: document.querySelectorAll('th[scope]').length,
             scripts: document.scripts.length, external: [...document.querySelectorAll('[src],[href]')].map(e => e.getAttribute('src') || e.getAttribute('href')).filter(u => /^(https?:)?\\/\\//.test(u)).length };
  })()`,
});
console.log(JSON.stringify(r.result.result.value));
const shot = await send('Page.captureScreenshot', { format: 'png' });
writeFileSync(process.argv[2], Buffer.from(shot.result.data, 'base64'));
ws.close();
