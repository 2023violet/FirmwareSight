﻿param([string]$Exe, [string]$Out, [string]$Fixtures)
# R4 native smoke: QA-identifier build only, empty QA store, Owner store hashed read-only.
# The QA store this run creates is KEPT under a unique name and listed, never deleted.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
New-Item -ItemType Directory -Force $Out | Out-Null
$a = $env:APPDATA
$owner = "$a\com.firmwaresight.desktop"
function OwnerHashes { Get-ChildItem $owner -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($owner.Length))" } }
$before = OwnerHashes
$aside = "com.firmwaresight.desktop.qa.r4-aside-" + (Get-Date -Format "HHmmss")
if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $aside }
$log = @()
function Rec($id, $verdict, $text) { $script:log += "$id`t$verdict`t$text"; "$id $verdict $text" }
function J($expr) { (node cdp.mjs eval $expr | Out-String).Trim() -replace '\s+', ' ' }
function Click($name) { node cdp.mjs click $name | Out-Null }
function V($cond) { if ($cond) { 'PASS' } else { 'FAIL' } }
function JClick($expr) { J "(() => { const el = $expr; if (!el) return 'MISSING'; el.click(); return 'ok' })()" }
function Region($name) { "[...document.querySelectorAll('[aria-label]')].find(n => n.getAttribute('aria-label') === '$name')" }
function PickBaseline($index) {
  JClick "[...document.querySelectorAll('[role=combobox]')].find(b => document.getElementById(b.getAttribute('aria-labelledby'))?.textContent === '基线（可选）')" | Out-Null
  Start-Sleep 1
  JClick "document.querySelectorAll('[role=option]')[$index]" | Out-Null
  Start-Sleep 1
}
try {
  $env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9333'
  $p = Start-Process $Exe -PassThru
  Start-Sleep 7
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null

  foreach ($side in 'base', 'target') {
    Click '选择固件镜像文件'
    & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\firmware.elf" | Out-Null
    Start-Sleep 1
    Click '添加 MAP'
    & .\dialog.ps1 -ProcId $p.Id -FilePath "$Fixtures\$side\firmware.map" | Out-Null
    Start-Sleep 1
    Click '分析'
    Start-Sleep 3
  }

  Click '发布 页面'
  Start-Sleep 2
  $steps = J "[...document.querySelectorAll('h2')].map(h => h.textContent).filter(x => x.startsWith('第 ')).join('|')"
  node cdp.mjs shot "$Out\01-release-setup.png" | Out-Null
  PickBaseline 1
  $base = J "[...document.querySelectorAll('[role=combobox]')].map(b => b.getAttribute('data-value')).join('|')"
  Rec 'R01' (V ($steps -match '第 1 步.*第 2 步.*第 3 步' -and $base -notmatch '\|$')) "no run: three numbered steps ($steps); BuildPicker chose a baseline ($base)"

  Click '运行 Gate'
  Start-Sleep 3
  $lead = J "($(Region '门禁结论'))?.textContent"
  $bar = J "($(Region '本页主体'))?.textContent"
  $focus = J "document.activeElement?.getAttribute('aria-label')"
  node cdp.mjs shot "$Out\02-release-verdict-1440.png" | Out-Null
  Rec 'R02' (V ($lead -match '不是认证' -and $bar -match '3c9daa4f7c09' -and $bar -match '最新' -and $focus -match '门禁结论')) "run: lead $lead | SubjectBar $bar | focus on $focus"

  $line = J "($(Region '运行设置'))?.textContent"
  $tabs = J "[...document.querySelectorAll('[role=tab]')].map(t => t.textContent).join('|')"
  $groups = J "[...document.querySelectorAll('h3')].map(h => h.textContent).join('|')"
  $collapsed = J "[...document.querySelectorAll('button[aria-expanded=false]')].map(b => b.textContent).filter(x => x.startsWith('展开')).join('|')"
  Rec 'R03' (V ($line -match '构建 firmware.elf' -and $line -match '基线 firmware.elf' -and $line -match '附件 0 个' -and $tabs -match '结论\|证据\|发布包')) "settings line: $line | tabs $tabs | groups $groups | collapsed: $collapsed"

  $basis = J "[...document.querySelectorAll('button')].map(b => b.textContent).find(x => x.startsWith('查看 ') && x.endsWith(' 的依据'))"
  Click ($basis.Trim('"'))
  Start-Sleep 1
  $insp = J "(() => { const a = document.querySelector('aside[aria-labelledby=fs-inspector-title]'); return a ? a.getAttribute('role') + ' | ' + a.textContent : null })()"
  node cdp.mjs shot "$Out\03-finding-basis-inspector.png" | Out-Null
  Rec 'R04' (V ($insp -match 'complementary' -and $insp -match '有效严重度')) "a finding's basis opens the docked Inspector ($basis): $insp"
  & .\resize.ps1 -ProcId $p.Id -W 1100 -H 760 | Out-Null
  Start-Sleep 1
  $sheet = J "(() => { const a = document.querySelector('aside[aria-labelledby=fs-inspector-title]'); return a ? a.getAttribute('role') + ' modal=' + a.getAttribute('aria-modal') : null })()"
  node cdp.mjs shot "$Out\04-inspector-sheet-1100.png" | Out-Null
  Rec 'R05' (V ($sheet -match 'dialog modal=true')) "below 1280 the open Inspector becomes a modal sheet: $sheet"
  & .\resize.ps1 -ProcId $p.Id -W 1456 -H 939 | Out-Null
  Start-Sleep 1
  Click '关闭证据面板'

  Click '证据'
  Start-Sleep 1
  $ev = J "({ record: !!($(Region 'FirmwareSight 策略就绪度')) || [...document.querySelectorAll('h2')].some(h => h.textContent.includes('就绪')), tables: document.querySelectorAll('[role=tabpanel] table').length, h3: [...document.querySelectorAll('[role=tabpanel] h3')].map(h => h.textContent).join('|') })"
  node cdp.mjs shot "$Out\05-evidence-view.png" | Out-Null
  Rec 'R06' (V ($ev -match '"tables": [1-9]')) "Evidence view: $ev"

  Click '发布包'
  Start-Sleep 1
  $bundle = J "(() => { const b = [...document.querySelectorAll('button')].find(x => x.textContent === '准备发布包'); return { prepareDisabled: b?.disabled, text: document.querySelector('[role=tabpanel]')?.textContent.slice(0, 220) } })()"
  node cdp.mjs shot "$Out\06-bundle-view.png" | Out-Null
  Rec 'R07' (V ($bundle -match 'prepareDisabled')) "Bundle view: $bundle"

  Click '编辑设置'
  Start-Sleep 1
  Click '编辑策略'
  Start-Sleep 1
  $dlg = J "(() => { const d = [...document.querySelectorAll('[role=dialog]')].find(x => x.textContent.includes('编辑项目策略')); return d ? 'modal=' + d.getAttribute('aria-modal') + ' fields=' + d.querySelectorAll('input,select').length : null })()"
  node cdp.mjs shot "$Out\07-policy-sheet.png" | Out-Null
  J "document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))" | Out-Null
  Start-Sleep 1
  $after = J "({ open: document.querySelectorAll('[role=dialog]').length, focus: document.activeElement?.textContent })"
  Rec 'R08' (V ($dlg -match 'modal=true' -and $after -match '"open": 0' -and $after -match '编辑策略')) "policy editor in a Sheet: $dlg; after Esc: $after"

  PickBaseline 0
  $bar = J "($(Region '本页主体'))?.textContent"
  node cdp.mjs shot "$Out\08-settings-moved.png" | Out-Null
  Rec 'R09' (V ($bar -match '已保留上一次运行')) "moving the baseline to none marks the run on screen as kept: $bar"
  PickBaseline 1
  $bar2 = J "($(Region '本页主体'))?.textContent"
  Rec 'R10' (V ($bar2 -match '最新')) "choosing the judged baseline again reads Latest: $bar2"

  Click '导出'
  Start-Sleep 1
  Click '导出 PNG'
  $d = & .\dialog.ps1 -ProcId $p.Id -FilePath '' -Cancel
  Start-Sleep 1
  $status = J "[...document.querySelectorAll('[role=status]')].map(n => n.textContent).join(' | ')"
  $alerts = J "document.querySelectorAll('[role=alert]').length"
  Rec 'R11' (V ($d -eq 'DIALOG_CANCELLED' -and $status -match '已取消导出' -and $alerts -eq '0')) "export PNG from the header menu, cancelled in the native Save dialog: (alerts $alerts) $status"

  $dark = (node cdp.mjs darkshot "$Out\09-release-dark.png" | Out-String).Trim() -replace '\s+', ' ' -replace ' saved \S+', ''
  Rec 'R12' (V ($dark -match '"theme":"dark"')) "dark theme on Release: $dark"

  Click '设置 页面'
  Start-Sleep 1
  $en = JClick "[...document.querySelectorAll('input[type=radio]')].find(i => document.querySelector('label[for=' + JSON.stringify(i.id) + ']')?.textContent.trim() === 'English')"
  Start-Sleep 2
  Click 'Release page'
  Start-Sleep 2
  $enLead = J "($(Region 'Gate verdict'))?.textContent"
  $enTabs = J "[...document.querySelectorAll('[role=tab]')].map(t => t.textContent).join('|')"
  node cdp.mjs shot "$Out\10-release-english.png" | Out-Null
  Rec 'R13' (V ($en -match 'ok' -and $enLead -match 'not a certification' -and $enTabs -match 'Findings\|Evidence\|Bundle')) "English: lead $enLead | tabs $enTabs"

  Stop-Process -Id $p.Id
  Start-Sleep 2
}
finally {
  Get-Process -Name firmwaresight-desktop -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe } | Stop-Process -Force
  Start-Sleep 1
  $kept = "com.firmwaresight.desktop.qa.r4-kept-" + (Get-Date -Format "HHmmss")
  if (Test-Path "$a\com.firmwaresight.desktop.qa") { Rename-Item "$a\com.firmwaresight.desktop.qa" $kept }
  if (Test-Path "$a\$aside") { Rename-Item "$a\$aside" "com.firmwaresight.desktop.qa" }
  "kept QA store: $kept"
}
$after = OwnerHashes
Rec 'R14' (V (-not (Compare-Object $before $after))) "Owner app data unchanged: $($after.Count) files, identical hashes"
Rec 'R15' 'NOT_RUN' 'window minimum 1024x720 drag clamp (carried from R1 A10; needs a human drag)'
$log | Set-Content -Encoding utf8 "$Out\results.tsv"
